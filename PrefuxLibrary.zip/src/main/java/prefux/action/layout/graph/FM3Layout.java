/*  Author: Daniel Sund
*   The following is an attempt at implementing the FM3 algorithm.
*/
package prefux.action.layout.graph;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

import prefux.action.layout.Layout;
import prefux.data.Graph;
import prefux.util.PrefuseLib;
import prefux.data.Node;
import prefux.data.Edge;
import prefux.data.util.Point2D;
import prefux.data.util.Rectangle2D;
import prefux.visual.VisualItem;

public class FM3Layout extends Layout 
{
    protected String                   m_nodeGroup;     // Name of the node group
    protected String                   m_edgeGroup;     // Name of the edge group
    protected double                   uniform_edge_length;
    protected boolean                  first_run = true;
    protected double                   aspect_ratio = 1.5; // Defined as (width/height)
    private FM3_Graph                  fm3_graph; // original version of the graph
    protected boolean                  run_restrict_to_grid = true;
    private Counter                    elapsed_time_counter;
    private Edge_Cross_Counter         edge_cross_counter;
    
    protected double                   spring_stiffness_factor;
    protected double                   repulsion_factor;
    protected double                   displacement_factor;
    protected double                   force_threshold;
    
    /*  Constructor for creating a new FM3 Layout.
    */
    public FM3Layout(String group)
    {
        this( group, 50.0, 0.01, 100.0, 0.5, 0.2 );
    }
    
    public FM3Layout(String group, double desired_edge_length, double spring_stiffness, double repulsion, double displacement, double force_thresh )
    {
        super(group);
        m_nodeGroup = PrefuseLib.getGroupName(group, Graph.NODES);
	m_edgeGroup = PrefuseLib.getGroupName(group, Graph.EDGES);
        uniform_edge_length = desired_edge_length;
        elapsed_time_counter = new Counter();
        edge_cross_counter = new Edge_Cross_Counter();
        spring_stiffness_factor = spring_stiffness;
        repulsion_factor = repulsion;
        displacement_factor = displacement;
        force_threshold = force_thresh;
    }
    
    public void run(double frac) 
    {
        if( first_run )
        {
            fm3_graph = new FM3_Graph();
            
            System.out.println("Run started...");
            elapsed_time_counter.start();
            
            fm3_preprocessing_step();
            
            fm3_divide_et_impera();
            
            first_run = false;
            
            elapsed_time_counter.stop();
            System.out.println("Done. Total runtime: "+elapsed_time_counter.get_elapsed_time());
            edge_cross_counter.calculate();
        }
    }
    
    // FM3 specific classes
    private class FM3_Graph
    {
        public FM3_Graph()
        {
            Map<String,FM3_Node> node_map = new HashMap<>();
            ArrayList<String[]> edges_to_create = new ArrayList<>();
            for( Iterator<VisualItem> iter = m_vis.visibleItems(m_nodeGroup) ; iter.hasNext() ; )
            {
                VisualItem vis_node = iter.next();
                FM3_Node node = new FM3_Node(vis_node);
                node_list.add(node);
                node_map.put(((Node)vis_node).toString(), node);
                
                // Get data for edges
                for( Iterator<? extends Edge> edge_iter = ((Node)vis_node).outEdges() ; edge_iter.hasNext() ; )
                {
                    Edge edge = edge_iter.next();
                    String[] edge_data = new String[2];
                    edge_data[0] = edge.getSourceNode().toString(); // source
                    edge_data[1] = edge.getTargetNode().toString(); // target
                    edges_to_create.add(edge_data);
                }
                
            }
            for( String[] edge_data : edges_to_create )
            {
                FM3_Node src_node = node_map.get(edge_data[0]);
                FM3_Node trg_node = node_map.get(edge_data[1]);
                FM3_Edge new_edge = new FM3_Edge( src_node, trg_node );
                edge_list.add(new_edge);
                src_node.add_edge( new_edge );
                trg_node.add_edge( new_edge );
                src_node.add_neighbor( trg_node );
                trg_node.add_neighbor( src_node );
            }
        }
        
        public FM3_Graph( ArrayList<FM3_Node> nodes, ArrayList<FM3_Edge> edges )
        {
            for( FM3_Node node : nodes )
                node_list.add(node);
            for( FM3_Edge edge : edges )
            {
                edge_list.add(edge);
                edge.get_source().add_edge( edge );
                edge.get_target().add_edge( edge );
                edge.get_source().add_neighbor( edge.get_target() );
                edge.get_target().add_neighbor( edge.get_source() );
            }
        }
        
        public FM3_Graph( ArrayList<FM3_Node> nodes )
        {
            for( FM3_Node node : nodes )
                node_list.add(node);
        }
        
        public Iterator<FM3_Node> nodes(){ return node_list.iterator(); }
        public Iterator<FM3_Edge> edges(){ return edge_list.iterator(); }
        public int node_count(){ return node_list.size(); }
        public int edge_count(){ return edge_list.size(); }
        public void add_edge( FM3_Edge edge )
        {
            edge_list.add(edge);
            edge.get_source().add_edge( edge );
            edge.get_target().add_edge( edge );
            edge.get_source().add_neighbor( edge.get_target() );
            edge.get_target().add_neighbor( edge.get_source() );
        }
        public FM3_Edge get_edge( FM3_Node src, FM3_Node trg )
        {
            for( FM3_Edge edge : edge_list )
            {
                if( (edge.get_source()==src && edge.get_target()==trg)
                        || (edge.get_source()==trg && edge.get_target()==src) )
                    return edge;
            }
            return null;
        }
        
        public Iterator<FM3_Node> suns(){ return suns.iterator(); }
        public Iterator<FM3_Node> planets(){ return planets.iterator(); }
        public Iterator<FM3_Node> moons(){ return moons.iterator(); }
        public void add_sun( FM3_Node node ){ suns.add(node); }
        public void add_planet( FM3_Node node ){ planets.add(node); }
        public void add_moon( FM3_Node node ){ moons.add(node); }
        
        private final ArrayList<FM3_Node> node_list = new ArrayList<>();
        private final ArrayList<FM3_Edge> edge_list = new ArrayList<>();
        private final ArrayList<FM3_Node> suns = new ArrayList<>();
        private final ArrayList<FM3_Node> planets = new ArrayList<>();
        private final ArrayList<FM3_Node> moons = new ArrayList<>();
    }
    private class FM3_Node
    {
        public FM3_Node( VisualItem vis_node )
        {
            visual_node = vis_node;
            ancestor_node = null;
        }
        
        public FM3_Node( FM3_Node ancestor )
        {
            visual_node = ancestor.get_visual_node();
            ancestor_node = ancestor;
        }
        
        public VisualItem get_visual_node(){ return visual_node; }
        public void add_edge( FM3_Edge edge ){ edges.add(edge); }
        public FM3_Node get_ancestor(){ return ancestor_node; }
        public Iterator<FM3_Node> neighbors(){ return neighbors.iterator(); }
        public void add_neighbor( FM3_Node neighbor ){ neighbors.add(neighbor); }
        public Iterator<FM3_Edge> edges(){ return edges.iterator(); }
        public int get_star_mass(){ return star_mass; }
        public void set_star_mass( int mass ){ star_mass = mass; }
        public void set_sun(boolean bool){ is_sun = bool; }
        public boolean is_sun(){ return is_sun; }
        public void set_planet(boolean bool){ is_planet = bool; }
        public boolean is_planet(){ return is_planet; }
        public void set_moon(boolean bool){ is_moon = bool; }
        public boolean is_moon(){ return is_moon; }
        public FM3_Node get_owner(){ return owner; }
        public void set_owner(FM3_Node own){ owner = own; }
        public void set_distance_to_owner( double dist ){ distance_to_owner = dist; }
        public double get_distance_to_owner(){ return distance_to_owner; }
        public void set_descendant( FM3_Node desc ){ descendant_node = desc; }
        public FM3_Node get_descendant(){ return descendant_node; }
        public boolean is_neighbor( FM3_Node node ){ return neighbors.contains(node); }
        public boolean initial_placement_generated(){ return inital_placement_generated; }
        public void initial_placement_set( boolean bool )
        {
            inital_placement_generated=bool;
            if( ancestor_node != null )
                ancestor_node.initial_placement_set(bool);
        }
        public void add_rpp_list( FM3_Node node, double val )
        {
            rpp_list_node.add(node);
            rpp_list_value.add(val);
        }
        public ArrayList<FM3_Node> get_rpp_list_node(){ return rpp_list_node; }
        public ArrayList<Double> get_rpp_list_value(){ return rpp_list_value; }
        
        // Forces
        public void clear_spring_force(){ spring_force_x=0.0; spring_force_y=0.0; }
        public void clear_repulsion_force(){ repulsion_force_x=0.0; repulsion_force_y=0.0; }
        public void clear_displacement(){ displ_x=0.0; displ_y=0.0; }
        public void clear_resulting_force(){ res_force_x=0.0; res_force_y=0.0; }
        public void add_spring_force( double x, double y ){ spring_force_x += x; spring_force_y += y; }
        public void add_repulsion_force( double x, double y ){ repulsion_force_x += x; repulsion_force_y += y; }
        public void set_displacement( double x, double y ){ displ_x = x; displ_y = y; }
        public void add_resulting_force( double x, double y ){ res_force_x += x; res_force_y += y; }
        public double get_spring_force_x(){ return spring_force_x; }
        public double get_spring_force_y(){ return spring_force_y; }
        public double get_repulsion_force_x(){ return repulsion_force_x; }
        public double get_repulsion_force_y(){ return repulsion_force_y; }
        public double get_displacement_x(){ return displ_x; }
        public double get_displacement_y(){ return displ_y; }
        public double get_resulting_force_x(){ return res_force_x; }
        public double get_resulting_force_y(){ return res_force_y; }
        public String get_S_index(){ return s_index; }
        public FM3_QuadTreeNode get_S_link(){ return s_link; }
        public void set_S_link( FM3_QuadTreeNode node ){ s_link = node; }
        public void set_S_index( String c ){ s_index = c; }
        public void clear_S_link_index(){ s_index = ""; s_link = null; }
        
        private VisualItem visual_node = null;
        private double spring_force_x = 0.0;
        private double spring_force_y = 0.0;
        private double repulsion_force_x = 0.0;
        private double repulsion_force_y = 0.0;
        private double displ_x = 0.0;
        private double displ_y = 0.0;
        private double res_force_x = 0.0;
        private double res_force_y = 0.0;
        private final ArrayList<FM3_Edge> edges = new ArrayList<>();
        private final ArrayList<FM3_Node> neighbors = new ArrayList<>();
        private final FM3_Node ancestor_node;
        private FM3_Node descendant_node = null;
        private boolean inital_placement_generated = false;
        private String s_index = "";
        private FM3_QuadTreeNode s_link = null;
        
        // For Galaxy Partitioning
        private int star_mass = 1;
        private boolean is_sun = false;
        private boolean is_planet = false;
        private boolean is_moon = false;
        private FM3_Node owner = null;
        private double distance_to_owner = 0.0;
        
        // Relative-Path-Position List
        private final ArrayList<Double> rpp_list_value = new ArrayList<>();
        private final ArrayList<FM3_Node> rpp_list_node = new ArrayList<>();
    }
    private class FM3_Edge
    {
        public FM3_Edge( FM3_Node src, FM3_Node trg )
        {
            source = src;
            target = trg;
            ancestor_edge = null;
        }
        
        public FM3_Edge( FM3_Node src, FM3_Node trg, FM3_Edge ancestor )
        {
            source = src;
            target = trg;
            ancestor_edge = ancestor;
        }
        
        public FM3_Node get_source(){ return source; }
        public FM3_Node get_target(){ return target; }
        public void set_desired_length(double value){ desired_length = value; }
        public double get_desired_length(){ return desired_length; }
        public FM3_Edge get_ancestor(){ return ancestor_edge; }
        public void set_multilevel_edge_count( int value ){ multilevel_edge_count = value; }
        public int get_multilevel_edge_count(){ return multilevel_edge_count; }
        
        private FM3_Node source = null;
        private FM3_Node target = null;
        private double desired_length = 0.0;
        private final FM3_Edge ancestor_edge;
        private int multilevel_edge_count = 0; // keeps track of how many multilevel edges this edge represents
    }
    
    private void fm3_preprocessing_step()
    {
        // Calculate the desired edge lengths
        for( Iterator<FM3_Edge> edge_it = fm3_graph.edges(); edge_it.hasNext() ; )
        {
            FM3_Edge edge = edge_it.next();
            edge.set_desired_length(uniform_edge_length);
        }
    }
    
    private void fm3_divide_et_impera()
    {
        ArrayList<FM3_Graph> subgraphs = new ArrayList<>();
        
        fm3_divide_step( subgraphs );
        
        for( FM3_Graph subgraph : subgraphs )
        {
            fm3_multilevel_step( subgraph );
        }
        
        fm3_impera_step( subgraphs );
    }
    
    private void fm3_divide_step( ArrayList<FM3_Graph> subgraphs )
    {
        // divide the disconnected graph into an array of connected graphs
        ArrayList<FM3_Node> already_visited = new ArrayList<>();
        Map<FM3_Node,Integer> component_id = new HashMap<>();
        int id = 0;
        for( Iterator<FM3_Node> node_it = fm3_graph.nodes(); node_it.hasNext() ; )
        {
            FM3_Node node = node_it.next();
            if( !already_visited.contains(node) )
            {
                ArrayList<FM3_Node> component_nodes = new ArrayList<>();
                fm3_find_component(node, id, component_id, already_visited, component_nodes);
                subgraphs.add( fm3_subgraph( fm3_graph, component_nodes) );
                id++;
            }
        }
        
        // Assign Desired Edge Lengths
        for( FM3_Graph subgraph : subgraphs )
        {
            for( Iterator<FM3_Edge> edge_it = subgraph.edges() ; edge_it.hasNext() ; )
            {
                FM3_Edge edge = edge_it.next();
                edge.set_desired_length( edge.get_ancestor().get_desired_length() );
            }
        }
    }
    
    private void fm3_find_component( FM3_Node node, int id, Map<FM3_Node,Integer> component_id, ArrayList<FM3_Node> already_visited, ArrayList<FM3_Node> component_nodes )
    {
        component_id.put(node, id);
        already_visited.add(node);
        component_nodes.add(node);
        for( Iterator<FM3_Node> neighbor_it = node.neighbors() ; neighbor_it.hasNext() ; )
        {
            FM3_Node neighbor = neighbor_it.next();
            if( !already_visited.contains(neighbor) )
            {
                fm3_find_component(neighbor, id, component_id, already_visited, component_nodes);
            }
        }
    }
    
    private void fm3_multilevel_step( FM3_Graph graph )
    {
        // Coarsening Phase
        int i=0, sum=0, d=5, c=50;
        double s = 1.25;
        ArrayList<FM3_Graph> graph_array = new ArrayList<>();
        graph_array.add(graph);
        do
        {
            // Create a galaxy partitioning & collapse to a new graph
            fm3_select_by_star_mass( graph_array.get(i) );
            graph_array.add( fm3_collapse( graph_array.get(i) ) );
            i++;
            if( graph_array.get(i).edge_count() > (graph_array.get(i-1).edge_count())/s )
                sum++;
        }
        while( graph_array.get(i).node_count() >= c && sum <= d );
        int last_level = i;
        
        // Refinement Phase
        
        // Generate a random intial placements for the nodes of the smallest (last) multilevel
        fm3_generate_random_initial_placement( graph_array.get(i), fm3_graph.node_count() );
        
        // Force Calculation for this multilevel
        fm3_grid_embedder( graph_array.get(i), i, last_level );
        
        // Loop through the remaining multilevels
        i--;
        while( i >= 0 )
        {
            // Generate initial placement for this multilevel
            fm3_generate_initial_placement( graph_array.get(i) );
            
            // Calculate forces and apply them on the nodes
            fm3_grid_embedder( graph_array.get(i), i, last_level );
            i--;
        }
    }
    
    private void fm3_grid_embedder( FM3_Graph graph, int current_multilevel, int max_multilevel )
    {
        // Init
        int max_iter, i=0;
        double springfactor=spring_stiffness_factor, repulsionfactor=repulsion_factor, s=displacement_factor, t=force_threshold, avg_force;
        
        // Calculate the maximum number of iterations
        max_iter = fm3_calculate_max_iter(current_multilevel, max_multilevel);
        
        // Loop until the stopping criterion is met
        do
        {
            // Restrict to grid
            if( run_restrict_to_grid )
                fm3_restrict_to_grid( graph, 10, 1, fm3_graph.node_count() );
            
            // Calculate Spring Forces
            fm3_calculate_spring_forces(graph);
            
            // Calculate Repulsive Forces
            fm3_force_approx(graph);
            
            // Calculate Resulting Forces
            fm3_calculate_resulting_force( graph, springfactor, repulsionfactor );
            
            // Calculate Displacement
            fm3_calculate_displacement( graph, s );
            
            // Re-position the nodes based on the displacement
            fm3_move_nodes(graph);
            
            // Calculate avrage total force
            avg_force = 0.0;
            for( Iterator<FM3_Node> iter = graph.nodes() ; iter.hasNext() ; )
            {
                FM3_Node node = iter.next();
                avg_force += Math.abs(node.get_displacement_x()) + Math.abs(node.get_displacement_y());
            }
            avg_force = avg_force/graph.node_count();
            
            i++;
        }
        while( i<=max_iter && avg_force>=t );
        
        // Restrict to grid
        if( run_restrict_to_grid )
            fm3_restrict_to_grid( graph, 10, 1, fm3_graph.node_count() );
    }
    
    // Calculates and returns the maximum iteration for the grid_embedder
    private int fm3_calculate_max_iter( double current_multilevel, double max_multilevel )
    {
        if( current_multilevel == 0 )
            return 30;
        else if( current_multilevel == max_multilevel )
            return 300;
        else
            return (int)(270*current_multilevel/max_multilevel+30);
    }
    
    private void fm3_calculate_spring_forces( FM3_Graph graph )
    {
        for( Iterator<FM3_Node> iter = graph.nodes(); iter.hasNext() ; )
        {
            FM3_Node source = iter.next();
            source.clear_spring_force();
            Point2D src_node = new Point2D( source.get_visual_node().getX(), source.get_visual_node().getY() );
            for( Iterator<FM3_Edge> edge_iter = source.edges() ; edge_iter.hasNext(); )
            {
                FM3_Edge edge = edge_iter.next();
                FM3_Node target = (source==edge.get_source()?edge.get_target():edge.get_source());
                Point2D trg_node = new Point2D( target.get_visual_node().getX(), target.get_visual_node().getY() );
                double distance = src_node.distance(trg_node);
                double desired_length = edge.get_desired_length();
                if( desired_length != 0 && distance>0 )
                {
                    double temp_force = Math.log10(distance/desired_length) * distance;
                    double distance_x = trg_node.getX() - src_node.getX();
                    double distance_y = trg_node.getY() - src_node.getY();
                    double temp_force_x = distance_x * temp_force;
                    double temp_force_y = distance_y * temp_force;
                    source.add_spring_force( temp_force_x, temp_force_y );
                }
            }
        }
    }
    
    private void fm3_force_approx( FM3_Graph graph )
    {
        int crossover_point = 100;
        
        if( graph.node_count() <= crossover_point )
        {
            // Naive Force Calculation
            fm3_calculate_repulsion_forces( graph );
        }
        else
        {
            // Calculate using multipole method
            // Step 1. Create the Reduced Bucket QuadTree
            FM3_QuadTree reduced_bucket_quadtree = new FM3_QuadTree(graph,2);
            
            // Step 2. Calculate the repulsion forces, using the QuadTree & the MultipoleFramework
            fm3_multipole_framework( graph, reduced_bucket_quadtree, 4 );
        }
    }
    
    private void fm3_calculate_repulsion_forces( FM3_Graph graph )
    {
        for( Iterator<FM3_Node> src_iter = graph.nodes() ; src_iter.hasNext() ; )
        {
            FM3_Node s_node = src_iter.next();
            double force_sum_x = 0.0;
            double force_sum_y = 0.0;
            
            for( Iterator<FM3_Node> trg_iter = graph.nodes() ; trg_iter.hasNext() ; )
            {
                FM3_Node t_node = trg_iter.next();
                if( t_node == s_node )
                    continue;
                
                double distance_x = s_node.get_visual_node().getX() - t_node.get_visual_node().getX();
                double distance_y = s_node.get_visual_node().getY() - t_node.get_visual_node().getY();
                double temp_force_x;
                double temp_force_y;
                Point2D node1 = new Point2D(s_node.get_visual_node().getX(),s_node.get_visual_node().getY());
                Point2D node2 = new Point2D(t_node.get_visual_node().getX(),t_node.get_visual_node().getY());
                double distance = node1.distance(node2);
                if( distance != 0 )
                {
                    temp_force_x = (distance_x / Math.pow(distance, 2));
                    temp_force_y = (distance_y / Math.pow(distance, 2));
                }
                else
                {
                    // Same position, random force vector
                    Random rand = new Random();
                    int random = rand.nextInt(4);
                    if( random == 0 ) // Down & Right
                    {
                        // random force between 1-5
                        temp_force_x = (rand.nextInt(5)+1);
                        temp_force_y = (rand.nextInt(5)+1);
                    }
                    else if( random == 1 ) // Down & Left
                    {
                        temp_force_x = (-1)*(rand.nextInt(5)+1);
                        temp_force_y = (rand.nextInt(5)+1);
                    }
                    else if( random == 2 ) // Up & Right
                    {
                        temp_force_x = (rand.nextInt(5)+1);
                        temp_force_y = (-1)*(rand.nextInt(5)+1);
                    }
                    else
                    {
                        temp_force_x = (-1)*(rand.nextInt(5)+1);
                        temp_force_y = (-1)*(rand.nextInt(5)+1);
                    }
                }
                force_sum_x = force_sum_x + temp_force_x;
                force_sum_y = force_sum_y + temp_force_y;
            }
            s_node.clear_repulsion_force();
            s_node.add_repulsion_force( force_sum_x, force_sum_y );
        }
    }
    
    private void fm3_calculate_resulting_force( FM3_Graph graph, double springfactor, double repulsionfactor )
    {
        for( Iterator<FM3_Node> iter = graph.nodes() ; iter.hasNext() ; )
        {
            FM3_Node node = iter.next();
            double force_x;
            double force_y;
            force_x = springfactor * node.get_spring_force_x() + repulsionfactor * node.get_repulsion_force_x();
            force_y = springfactor * node.get_spring_force_y() + repulsionfactor * node.get_repulsion_force_y();
            node.clear_resulting_force();
            node.add_resulting_force( force_x, force_y );
        }
    }
    
    private void fm3_calculate_displacement( FM3_Graph graph, double s )
    {
        for( Iterator<FM3_Node> iter = graph.nodes() ; iter.hasNext() ; )
        {
            FM3_Node node = iter.next();
            
            // calculate angle (radians)
            double angle, c, displ_factor;
            Point2D resulting_force = new Point2D( node.get_resulting_force_x(), node.get_resulting_force_y() );
            Point2D former_displ_force = complex_divide( new Point2D( node.get_displacement_x(), node.get_displacement_y() ), s );
            angle = Math.acos( resulting_force.normalize().dotProduct(former_displ_force.normalize()) );

            // calculate c based on the angle
            if( angle <= (1.0/6.0)*Math.PI && angle >= (-1.0/6.0)*Math.PI )
                c = 2.0;
            else if( (angle <= (2.0/6.0)*Math.PI && angle > (1.0/6.0)*Math.PI)
                    || (angle >= (-2.0/6.0)*Math.PI && angle < (-1.0/6.0)*Math.PI) )
                c = 3.0/2.0;
            else if( (angle <= (3.0/6.0)*Math.PI && angle > (2.0/6.0)*Math.PI)
                    || (angle >= (-3.0/6.0)*Math.PI && angle < (-2.0/6.0)*Math.PI) )
                c = 1.0;
            else if( (angle <= (4.0/6.0)*Math.PI && angle > (3.0/6.0)*Math.PI)
                    || (angle >= (-4.0/6.0)*Math.PI && angle < (-3.0/6.0)*Math.PI) )
                c = 2.0/3.0;
            else
                c = 1.0/3.0;

            if( complex_norm(resulting_force) > (c*complex_norm(former_displ_force))
                    && (c*complex_norm(former_displ_force)) > 0.0 )
            {
                displ_factor = s * c * complex_norm(former_displ_force);
            }
            else
            {
                displ_factor = s * complex_norm(resulting_force);
            }
            Point2D current_displ_force = complex_multiply( complex_divide(resulting_force,complex_norm(resulting_force)), displ_factor );
            node.set_displacement( current_displ_force.getX(), current_displ_force.getY() );
        }
    }
    
    // Creates a new graph containing the selected nodes from the given graph
    private FM3_Graph fm3_subgraph( FM3_Graph graph, ArrayList<FM3_Node> nodes )
    {
        Map<FM3_Node,FM3_Node> old_new_node_link = new HashMap<>();
        ArrayList<FM3_Edge> edges_to_create = new ArrayList<>();
        ArrayList<FM3_Edge> new_graph_edges = new ArrayList<>();
        ArrayList<FM3_Node> new_graph_nodes = new ArrayList<>();
        for( Iterator<FM3_Node> nodeIter = graph.nodes() ; nodeIter.hasNext() ; )
        {
            FM3_Node node = nodeIter.next();
            if( nodes.contains(node) )
            {
                FM3_Node new_node = new FM3_Node( node );
                new_graph_nodes.add(new_node);
                old_new_node_link.put(node, new_node);
                for( Iterator<FM3_Edge> edge_it = node.edges() ; edge_it.hasNext() ; )
                {
                    FM3_Edge edge = edge_it.next();
                    if( !edges_to_create.contains(edge) )
                        edges_to_create.add(edge);
                }
            }
        }
        for( Iterator<? extends FM3_Edge> edgeIter = graph.edges() ; edgeIter.hasNext() ; )
        {
            FM3_Edge edge = edgeIter.next();
            if( edges_to_create.contains(edge) )
            {
                FM3_Node s = old_new_node_link.get(edge.get_source());
                FM3_Node t = old_new_node_link.get(edge.get_target());
                FM3_Edge new_edge = new FM3_Edge( s, t, edge );
                new_graph_edges.add(new_edge);
            }
        }
        return new FM3_Graph( new_graph_nodes, new_graph_edges );
    }
    
    private void fm3_select_by_star_mass( FM3_Graph graph )
    {
        // 0. V is a copy of this graph's nodes
        // 1. First the star mass of each node is calculated
        // 2. Then the algortihm randomly selects a constant number of nodes from V
        // 3. The node with the lowest star mass among the sample is chosen as a sun-node.
        // 4. The algorithm deletes all nodes that have GT distance of 2 or less from V
        // 5. Then a new constant number of sample nodes are chosen from V and this process continues until V is empty.
        
        
        ArrayList<FM3_Node> v = new ArrayList<>();
        for( Iterator<FM3_Node> iter = graph.nodes() ; iter.hasNext() ; )
            v.add( iter.next() );
        Random rand = new Random();
        int random_int;
        FM3_Node chosen; // a random node from V
        while( !v.isEmpty() )
        {
            random_int = rand.nextInt(v.size());
            chosen = v.get(random_int);
            for( int count = 1; count<10 ; count++)
            {
                random_int = rand.nextInt(v.size());
                if( chosen.get_star_mass() > v.get(random_int).get_star_mass() )
                    chosen = v.get(random_int);
            } // when exiting this loop, a suitable node for making into a sun has been found and stored in "chosen"

            // Store the lowest mass node in the suns array.
            chosen.set_sun(true);
            graph.add_sun(chosen);
            
            for( Iterator<FM3_Node> iter = chosen.neighbors(); iter.hasNext() ; )
            {
                FM3_Node planet = iter.next();
                planet.set_planet(true);
                planet.set_owner(chosen);
                planet.set_moon(false);
                graph.add_planet(planet);
            }

            for( Iterator<FM3_Node> planet_iter = graph.planets() ; planet_iter.hasNext() ; )
            {
                FM3_Node planet = planet_iter.next();
                for( Iterator<FM3_Node> moon_iter = planet.neighbors(); moon_iter.hasNext() ; )
                {
                    FM3_Node potential_moon = moon_iter.next();
                    if( !potential_moon.is_sun() && !potential_moon.is_planet() && !potential_moon.is_moon() )
                    {
                        potential_moon.set_moon(true);
                        potential_moon.set_owner(planet);
                        v.remove(potential_moon);
                    }
                }
                v.remove(planet);
            }
            v.remove(chosen);
        } // Do all the above again until all nodes have been removed.

        // Add all moons
        for( Iterator<FM3_Node> iter = graph.nodes() ; iter.hasNext() ; )
        {
            FM3_Node node = iter.next();
            if( node.is_moon() )
                graph.add_moon(node);
        }
    }
    
    // This function returns a collapsed version of this graph based on galaxy partitioning
    private FM3_Graph fm3_collapse( FM3_Graph graph )
    {
        // The new graph should only contain this graph's sun nodes
        ArrayList<FM3_Node> new_graph_nodes = new ArrayList<>();
        for( Iterator<FM3_Node> iter = graph.suns() ; iter.hasNext() ; )
        {
            FM3_Node sun = iter.next();
            FM3_Node new_node = new FM3_Node(sun);
            sun.set_descendant(new_node);
            new_graph_nodes.add(new_node);
        }
        
        FM3_Graph new_graph = new FM3_Graph(new_graph_nodes);
        
        // Create "fake edges" between the suns
        ArrayList<FM3_Edge> solar_system_edges = new ArrayList<>();
        Map<FM3_Edge, FM3_Edge> edge_map = new HashMap();
        for( Iterator<FM3_Edge> iter = graph.edges() ; iter.hasNext() ; )
        {
            FM3_Edge edge = iter.next();
            FM3_Node source = edge.get_source();
            FM3_Node target = edge.get_target();

            // Set desired distance to owner node
            if( source.is_sun() ) // source=sun, target=planet
                target.set_distance_to_owner(edge.get_desired_length());
            else if( target.is_sun() ) // source=planet, target=sun
                source.set_distance_to_owner(edge.get_desired_length());
            else if( source.is_planet() && target.get_owner().equals(source) ) // source=planet, target=moon
                target.set_distance_to_owner(edge.get_desired_length());
            else if( target.is_planet() && target.get_owner().equals(target) ) // source=moon, target=planet
                source.set_distance_to_owner(edge.get_desired_length());

            if( source.is_sun() || target.is_sun() )
                continue;
            FM3_Node s_sun;
            FM3_Node t_sun;
            if( source.is_moon() )
                s_sun = source.get_owner().get_owner();
            else // source = planet
                s_sun = source.get_owner();
            if( target.is_moon() )
                t_sun = target.get_owner().get_owner();
            else // target = planet
                t_sun = target.get_owner();

            if( s_sun != t_sun )
            {
                // Get the corresponding higherlevel nodes
                FM3_Node higherlevel_source = s_sun.get_descendant();
                FM3_Node higherlevel_target = t_sun.get_descendant();

                // Create an edge
                if( higherlevel_source != null && higherlevel_target != null )
                {
                    solar_system_edges.add(edge);

                    // This is necessary, only one edge should be created per pair
                    FM3_Edge new_edge = new_graph.get_edge(higherlevel_source, higherlevel_target);
                    if( new_edge == null )
                    {
                        new_edge = new FM3_Edge( higherlevel_source, higherlevel_target );
                        new_graph.add_edge(new_edge);
                        edge_map.putIfAbsent(edge, new_edge);
                    }
                    else
                    {
                        edge_map.putIfAbsent(edge, new_edge);
                    }
                }
            }
        }

        // Recalculate the star_mass
        for( Iterator<FM3_Node> iter = graph.moons() ; iter.hasNext() ; )
        {
            FM3_Node moon = iter.next();
            FM3_Node planet = moon.get_owner();
            int mass = planet.get_star_mass()+moon.get_star_mass();
            planet.set_star_mass(mass); // add moon's mass to the planet's
        }
        for( Iterator<FM3_Node> iter = graph.planets() ; iter.hasNext() ; )
        {
            FM3_Node planet = iter.next();
            FM3_Node sun = planet.get_owner();
            int mass = sun.get_star_mass()+planet.get_star_mass();
            sun.set_star_mass(mass); // add planet's mass to the sun's
        }
        for( FM3_Node node : new_graph_nodes )
        {
            int mass = node.get_ancestor().get_star_mass();
            node.set_star_mass(mass);
        }
        
        // Initially store all edges' lengths
        for( FM3_Edge edge : solar_system_edges )
        {
            // Get source and target nodes and the suns they belong to
            FM3_Node source = edge.get_source();
            FM3_Node target = edge.get_target();
            FM3_Node s_sun;
            FM3_Node t_sun;
            if( source.is_moon() )
                s_sun = source.get_owner().get_owner();
            else // source = planet
                s_sun = source.get_owner();
            if( target.is_moon() )
                t_sun = target.get_owner().get_owner();
            else // target = planet
                t_sun = target.get_owner();

            // Edge lengths and path lengths
            double l_edge = edge.get_desired_length();
            double l_source;
            double l_target;
            if( source.is_planet() )
                l_source = source.get_distance_to_owner();
            else
                l_source = source.get_distance_to_owner() + source.get_owner().get_distance_to_owner();
            if( target.is_planet() )
                l_target = target.get_distance_to_owner();
            else
                l_target = target.get_distance_to_owner() + target.get_owner().get_distance_to_owner();

            // Calculate total path length
            double l_path = l_edge + l_source + l_target;

            // Set the length of the newly created edge
            FM3_Edge new_edge = edge_map.get(edge);
            if( new_edge.get_multilevel_edge_count() != 0 )
            {
                int count = new_edge.get_multilevel_edge_count();
                double new_desired_length = (new_edge.get_desired_length()*count+l_path) / (count+1.0);
                new_edge.set_desired_length( new_desired_length );
                new_edge.set_multilevel_edge_count(count+1);
            }
            else
            {
                new_edge.set_desired_length(l_path);
                new_edge.set_multilevel_edge_count(1);
            }

            // Store the neighbor sun & store the integer for the source node
            source.add_rpp_list( t_sun, (l_source/l_path) );
            // and for the target node
            target.add_rpp_list( s_sun, (l_target/l_path) );
        }

        return new_graph;
    }
    
    // Gives each node of this graph a random initial placement
    private void fm3_generate_random_initial_placement( FM3_Graph graph, int size )
    {
        double random_x, random_y;
        for( Iterator<FM3_Node> iter = graph.nodes() ; iter.hasNext() ; )
        {
            FM3_Node node = iter.next();
            VisualItem v_node = node.get_visual_node();

            // set random coordinates for placement
            Random rand = new Random();
            random_x = rand.nextInt( size*10 );
            random_y = rand.nextInt( size*10 );
            if( rand.nextInt(2)==0 )
                setX(v_node, v_node, random_x);
            else
                setX(v_node, v_node, (-1)*random_x);
            if( rand.nextInt(2)==0 )
                setY(v_node, v_node, random_y);
            else
                setY(v_node, v_node, (-1)*random_y);
            node.initial_placement_set(true);
        }
    }
    
    // Gives each node of this graph a placement based on RPP-lists
    private void fm3_generate_initial_placement( FM3_Graph graph )
    {
        for( Iterator<FM3_Node> iter = graph.nodes() ; iter.hasNext() ; )
        {
            FM3_Node node = iter.next();
            VisualItem v_node = node.get_visual_node();

            if( node.initial_placement_generated() )
                continue;

            // set the position based on the relative_path_position list
            double x, y;
            ArrayList<Double> quadruple_value = node.get_rpp_list_value();
            ArrayList<FM3_Node> quadruple_neighbor = node.get_rpp_list_node();
            FM3_Node quadruple_sun;
            if( node.is_moon() )
                quadruple_sun = node.get_owner().get_owner();
            else
                quadruple_sun = node.get_owner();
            VisualItem quadruple_sun_visual = quadruple_sun.get_visual_node();

            // Scenario 1 (rpp empty)
            // Scenario 2 (rpp contains EXACTLY one entry)
            // Scenario 3 (rpp contains > 1 entry)
            if( quadruple_value.isEmpty() )
            {
                // Node will be placed randomly with a specified radius from its sun
                Random rand = new Random();
                double random_x, random_y;
                if( node.is_moon() )
                {
                    random_x = rand.nextDouble()*(node.get_distance_to_owner() + node.get_owner().get_distance_to_owner());
                    random_y = Math.sqrt( Math.pow((node.get_distance_to_owner() + node.get_owner().get_distance_to_owner()), 2.0)
                            - Math.pow(random_x, 2.0) );
                }
                else
                {
                    random_x = rand.nextDouble()*node.get_distance_to_owner();
                    random_y = Math.sqrt( Math.pow(node.get_distance_to_owner(), 2.0) - Math.pow(random_x, 2.0) );
                }
                if( rand.nextInt(2)==0 )
                    x = quadruple_sun_visual.getX() + random_x;
                else
                    x = quadruple_sun_visual.getX() - random_x;
                if( rand.nextInt(2)==0 )
                    y = quadruple_sun_visual.getY() + random_y;
                else
                    y = quadruple_sun_visual.getY() - random_y;
            }
            else if( quadruple_value.size()==1 )
            {
                VisualItem quadruple_neighbor_visual = quadruple_neighbor.get(0).get_visual_node();
                x = quadruple_sun_visual.getX() + 
                        (quadruple_value.get(0)*(quadruple_neighbor_visual.getX()-quadruple_sun_visual.getX()));
                y = quadruple_sun_visual.getY() + 
                        (quadruple_value.get(0)*(quadruple_neighbor_visual.getY()-quadruple_sun_visual.getY()));
            }
            else
            {
                double sumX = 0.0;
                double sumY = 0.0;
                for( int i=0 ; i<quadruple_neighbor.size() ; i++ )
                {
                    VisualItem quadruple_neighbor_visual = quadruple_neighbor.get(i).get_visual_node();
                    sumX = sumX + quadruple_sun_visual.getX() + 
                            (quadruple_value.get(i)*(quadruple_neighbor_visual.getX()-quadruple_sun_visual.getX()));
                    sumY = sumY + quadruple_sun_visual.getY() + 
                            (quadruple_value.get(i)*(quadruple_neighbor_visual.getY()-quadruple_sun_visual.getY()));
                }
                x = sumX/quadruple_value.size();
                y = sumY/quadruple_value.size();
            }

            // place the node at these coordinates
            setX(v_node, v_node, x);
            setY(v_node, v_node, y);
            node.initial_placement_set(true);
        }
    }
    
    // Re-Positions the nodes based on displacement
    private void fm3_move_nodes( FM3_Graph graph )
    {
        for( Iterator<FM3_Node> iter = graph.nodes() ; iter.hasNext() ; )
        {
            FM3_Node node = iter.next();
            VisualItem v_node = node.get_visual_node();
            if( !v_node.isFixed() )
            {
                // Move node
                v_node.setX( v_node.getX()+node.get_displacement_x() );
                v_node.setY( v_node.getY()+node.get_displacement_y() );
            }
            else
            {
                // Clear force calculations for the node
                node.set_displacement(0.0, 0.0);
            }
        }
    }
    
    // This function restricts the nodes of a graph to a given boundry
    private void fm3_restrict_to_grid( FM3_Graph graph, double d1, double d2, double amount )
    {
        Rectangle2D grid = new Rectangle2D( (-1*Math.pow(amount, d2)*d1), (-1*Math.pow(amount, d2)*d1), (2.0*Math.pow(amount, d2)*d1), (2.0*Math.pow(amount, d2)*d1) );
        for( Iterator<FM3_Node> iter = graph.nodes() ; iter.hasNext() ; )
        {
            VisualItem node = iter.next().get_visual_node();
            // Check if out of bounds
            Point2D node_pos = new Point2D( node.getX(), node.getY() );
            if( !grid.contains(node_pos) )
            {
                double new_x, new_y, factor;
                if( Math.abs(node_pos.getX()) > Math.abs(node_pos.getY()) )
                {
                    if( node_pos.getX() < grid.getMinX() )
                        new_x = grid.getMinX();
                    else
                        new_x = grid.getMaxX();
                    factor = node_pos.getY()/node_pos.getX();
                    new_y = new_x * factor;
                }
                else if( Math.abs(node_pos.getX()) < Math.abs(node_pos.getY()) )
                {
                    if( node_pos.getY() < grid.getMinY() )
                        new_y = grid.getMinY();
                    else
                        new_y = grid.getMaxY();
                    factor = node_pos.getX()/node_pos.getY();
                    new_x = new_y * factor;
                }
                else
                {
                    if( node_pos.getX() < grid.getMinX() )
                        new_x = grid.getMinX();
                    else
                        new_x = grid.getMaxX();
                    if( node_pos.getY() < grid.getMinY() )
                        new_y = grid.getMinY();
                    else
                        new_y = grid.getMaxY();
                }
                node.setX(new_x);
                node.setY(new_y);
            }
            
            // Restrict to 2 decimals
            double x = node.getX();
            double y = node.getY();
            if( x % 0.01 != 0 )
            {
                node.setX( ((double)(int)(x*100))/100 );
            }
            if( y % 0.01 != 0 )
            {
                node.setY( ((double)(int)(y*100))/100 );
            }
        }
    }
    
    private void fm3_impera_step( ArrayList<FM3_Graph> components )
    {
        if( components.size() > 1 )
        {
            // 1. Find the bounding rectangles of each component.
            ArrayList<Rectangle2D> boundaries = new ArrayList<>();
            Map<Rectangle2D,FM3_Graph> boundary_graph_link = new HashMap<>();
            boolean first_node;
            double offset = 30.0;
            for( FM3_Graph component : components )
            {
                double x_min=0.0, x_max=0.0, y_min=0.0, y_max=0.0;
                first_node = true;
                for( Iterator<FM3_Node> node_it = component.nodes() ; node_it.hasNext() ; )
                {
                    VisualItem node = node_it.next().get_visual_node();
                    if( first_node )
                    {
                        x_min = node.getX();
                        x_max = node.getX();
                        y_min = node.getY();
                        y_max = node.getY();
                        first_node = false;
                    }
                    else
                    {
                        if( x_min > node.getX() )
                            x_min = node.getX();
                        if( x_max < node.getX() )
                            x_max = node.getX();
                        if( y_min > node.getY() )
                            y_min = node.getY();
                        if( y_max < node.getY() )
                            y_max = node.getY();
                    }
                }
                // Create boundary + offset
                Rectangle2D boundary = new Rectangle2D(x_min-offset, y_min-offset, (x_max-x_min)+(offset*2.0), (y_max-y_min)+(offset*2.0) );
                boundaries.add(boundary);
                boundary_graph_link.put(boundary, component);
            }
            
            // 2. Foreach component calculate each rectangle's "Alignment".
            for( int i=0 ; i<boundaries.size() ; i++ )
            {
                Rectangle2D boundary = boundaries.get(i);
                FM3_Graph current_graph = boundary_graph_link.get(boundary);
                double width_height_ratio = boundary.getWidth()/boundary.getHeight();
                if( !(aspect_ratio < 1 && width_height_ratio < 1)
                        && !(aspect_ratio >= 1 && width_height_ratio >=1) )
                {
                    boundaries.set( i, fm3_rotate_90( boundary, current_graph ) );
                    boundary_graph_link.put(boundaries.get(i), current_graph);
                }
            }
            
            // 3. "Sort" the rectangles into decreasing height order
            boundaries.sort(new compare_boundary_height());
            
            // 4. Use the sorted array of rectangles to "Pack" them together
            boolean first_box = true;
            ArrayList<Rectangle2D> rows = new ArrayList<>(); // previous_row = rows.get(rows.size()-1)
            double res_height = 0.0, res_width = 0.0;
            for( Rectangle2D bound : boundaries )
            {
                double x_coord, y_coord;
                if( first_box )
                {
                    // Place at the bottom left corner
                    x_coord = bound.getWidth()/2.0;
                    y_coord = bound.getHeight()/2.0;
                    bound = fm3_move_graph( bound, boundary_graph_link.get(bound), x_coord, y_coord );
                    rows.add( new Rectangle2D(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight()) );
                    res_height = bound.getHeight();
                    res_width = bound.getWidth();
                    first_box = false;
                }
                else
                {
                    // Calculate resulting drawing area for each case with regard to desired aspect ratio
                    
                    // Case 1. Place on existing row to the right of the previous box.
                    Rectangle2D drawing_area_case_1 = new Rectangle2D(0.0, 0.0, Math.max( rows.get(rows.size()-1).getWidth()+bound.getWidth(), res_width), res_height );
                    if( drawing_area_case_1.getWidth() > (drawing_area_case_1.getHeight()*aspect_ratio) )
                        drawing_area_case_1 = new Rectangle2D( 0.0, 0.0, drawing_area_case_1.getWidth(), drawing_area_case_1.getWidth()/aspect_ratio );
                    else
                        drawing_area_case_1 = new Rectangle2D( 0.0, 0.0, drawing_area_case_1.getHeight()*aspect_ratio, drawing_area_case_1.getHeight() );
                    
                    // Case 2. Place on new row to the left above the previous box.
                    Rectangle2D drawing_area_case_2 = new Rectangle2D(0.0, 0.0, Math.max( bound.getWidth(), res_width), (res_height + bound.getHeight()) );
                    if( drawing_area_case_2.getWidth() > (drawing_area_case_2.getHeight()*aspect_ratio) )
                        drawing_area_case_2 = new Rectangle2D( 0.0, 0.0, drawing_area_case_2.getWidth(), drawing_area_case_2.getWidth()/aspect_ratio );
                    else
                        drawing_area_case_2 = new Rectangle2D( 0.0, 0.0, drawing_area_case_2.getHeight()*aspect_ratio, drawing_area_case_2.getHeight() );
                    
                    // Case 3. Rotate 90deg and place on any existing row with minimal width.
                    Rectangle2D drawing_area_case_3 = null;
                    Rectangle2D minimal_width_row = null;
                    for( Rectangle2D row : rows )
                    {
                        if( row.getHeight() < bound.getWidth() )
                            break;
                        if( minimal_width_row == null || minimal_width_row.getWidth() > row.getWidth())
                            minimal_width_row = row;
                    }
                    if( minimal_width_row != null )
                    {
                        drawing_area_case_3 = new Rectangle2D( 0.0, 0.0, Math.max( minimal_width_row.getWidth()+bound.getHeight(), res_width ), res_height );
                        if( drawing_area_case_3.getWidth() > (drawing_area_case_3.getHeight()*aspect_ratio) )
                            drawing_area_case_3 = new Rectangle2D( 0.0, 0.0, drawing_area_case_3.getWidth(), drawing_area_case_3.getWidth()/aspect_ratio );
                        else
                            drawing_area_case_3 = new Rectangle2D( 0.0, 0.0, drawing_area_case_3.getHeight()*aspect_ratio, drawing_area_case_3.getHeight() );
                    }
                    
                    // Choose the case that produces the smallest drawing area
                    if( drawing_area_case_1.getWidth() <= drawing_area_case_2.getWidth() && 
                            (drawing_area_case_3 == null || drawing_area_case_1.getWidth() <= drawing_area_case_3.getWidth()) )
                    {
                        // Go with case 1
                        x_coord = rows.get(rows.size()-1).getCenterX() + rows.get(rows.size()-1).getWidth()/2 + bound.getWidth()/2;
                        y_coord = rows.get(rows.size()-1).getCenterY();
                        bound = fm3_move_graph( bound, boundary_graph_link.get(bound), x_coord, y_coord );
                        
                        // Update rows array (extend the previous row), res_height & res_width
                        int row_index = (rows.size()-1);
                        rows.set( row_index, new Rectangle2D( rows.get(row_index).getMinX(), rows.get(row_index).getMinY(),
                                (rows.get(row_index).getWidth()+bound.getWidth()), rows.get(row_index).getHeight() ) );
                        res_width = Math.max( res_width, rows.get(row_index).getWidth() );
                    }
                    else if( drawing_area_case_2.getWidth() < drawing_area_case_1.getWidth() && 
                            (drawing_area_case_3 == null || drawing_area_case_2.getWidth() <= drawing_area_case_3.getWidth()) )
                    {
                        // Go with case 2
                        x_coord = bound.getWidth()/2;
                        y_coord = rows.get(rows.size()-1).getCenterY() + rows.get(rows.size()-1).getHeight()/2 + bound.getHeight()/2;
                        bound = fm3_move_graph( bound, boundary_graph_link.get(bound), x_coord, y_coord );
                        
                        // Update rows array (add a new row to it), res_height & res_width
                        rows.add( new Rectangle2D(bound.getMinX(), bound.getMinY(), bound.getWidth(), bound.getHeight()) );
                        res_height += bound.getHeight();
                        res_width = Math.max( bound.getWidth(), res_width);
                    }
                    else
                    {
                        // Go with case 3
                        x_coord = minimal_width_row.getCenterX() + (minimal_width_row.getWidth()/2) + (bound.getHeight()/2);
                        y_coord = minimal_width_row.getCenterY();
                        FM3_Graph current_graph = boundary_graph_link.get(bound);
                        bound = fm3_rotate_90( bound, current_graph );
                        boundary_graph_link.put(bound, current_graph);
                        bound = fm3_move_graph( bound, boundary_graph_link.get(bound), x_coord, y_coord );
                        
                        // Update rows array (extend an already existing row), res_height & res_width
                        int row_index = rows.indexOf(minimal_width_row);
                        rows.set( row_index, new Rectangle2D( rows.get(row_index).getMinX(), rows.get(row_index).getMinY(),
                                (rows.get(row_index).getWidth()+bound.getWidth()), rows.get(row_index).getHeight() ) );
                        res_width = Math.max( rows.get(row_index).getWidth(), res_width );
                    }
                }
            }
        }
    }
    
    // Comparator for Rectangle2D heights coordinate
    private class compare_boundary_height implements Comparator<Rectangle2D>
    {
        @Override
        public int compare(Rectangle2D t1, Rectangle2D t2)
        {
            return t1.getHeight() > t2.getHeight() ? -1 : t1.getHeight()==t2.getHeight() ? 0 : 1;
        }
    }
    
    // This function takes a graph and rotates it 90 degrees around its center point, returns the new boundary
    private Rectangle2D fm3_rotate_90( Rectangle2D boundary, FM3_Graph graph )
    {
        // Rotate all nodes 90 degrees (1.57079633 = pi/2 rads) around the center of the rectangle
        double x_offset = boundary.getCenterX();
        double y_offset = boundary.getCenterY();
        double angle = (Math.PI / 2.0);
        for( Iterator<FM3_Node> node_it = graph.nodes() ; node_it.hasNext() ; )
        {
            VisualItem node = node_it.next().get_visual_node();
            
            // Offset to rotate around the origin point
            double x_old = node.getX() - x_offset;
            double y_old = node.getY() - y_offset;
            
            // Rotate
            double x_new = y_old*Math.sin(angle) + x_old*Math.cos(angle);
            double y_new = y_old*Math.cos(angle) - x_old*Math.sin(angle);
            
            // Offset to get correct coordinate
            x_new += x_offset;
            y_new += y_offset;
            node.setX(x_new);
            node.setY(y_new);
        }
        
        // Update the new boundary (shift height with width, center is the same as before)
        boundary = new Rectangle2D( x_offset-(boundary.getHeight()/2), y_offset-(boundary.getWidth()/2), boundary.getHeight(), boundary.getWidth() );
        return boundary;
    }
    
    // This function takes a graph and moves it to a new position, returns the new boundary
    private Rectangle2D fm3_move_graph( Rectangle2D boundary, FM3_Graph graph, double new_center_x, double new_center_y )
    {
        double dist_x = new_center_x - boundary.getCenterX();
        double dist_y = new_center_y - boundary.getCenterY();
        for( Iterator<FM3_Node> node_it = graph.nodes() ; node_it.hasNext() ; )
        {
            VisualItem node = node_it.next().get_visual_node();
            
            node.setX( node.getX() + dist_x );
            node.setY( node.getY() + dist_y );
        }
        
        // Update the new boundary (shift height with width, center is the same as before)
        boundary = new Rectangle2D( (boundary.getMinX()+dist_x), (boundary.getMinY()+dist_y), boundary.getWidth(), boundary.getHeight() );
        return boundary;
    }
    
    private class FM3_QuadTree
    {
        public FM3_QuadTree( FM3_Graph graph, int leaf_capacity )
        {
            // Calculate a square region D containing all particles
            double x_min=0.0, x_max=0.0, y_min=0.0, y_max=0.0;
            boolean first = true;
            for( Iterator<FM3_Node> iter = graph.nodes() ; iter.hasNext(); )
            {
                FM3_Node particle = iter.next();
                if( first )
                {
                    x_min = particle.get_visual_node().getX();
                    x_max = particle.get_visual_node().getX();
                    y_min = particle.get_visual_node().getY();
                    y_max = particle.get_visual_node().getY();
                    first = false;
                }
                else
                {
                    if( x_min > particle.get_visual_node().getX() )
                        x_min = particle.get_visual_node().getX();
                    if( x_max < particle.get_visual_node().getX() )
                        x_max = particle.get_visual_node().getX();
                    if( y_min > particle.get_visual_node().getY() )
                        y_min = particle.get_visual_node().getY();
                    if( y_max < particle.get_visual_node().getY() )
                        y_max = particle.get_visual_node().getY();
                }
            }
            Rectangle2D square_d = new Rectangle2D( x_min, y_min, Math.abs(Math.max(y_max-y_min, x_max-x_min)), Math.abs(Math.max(y_max-y_min, x_max-x_min)) );
            
            // Create sorted coordinate lists Sx & Sy
            for( Iterator<FM3_Node> iter = graph.nodes() ; iter.hasNext(); )
            {
                FM3_Node particle = iter.next();
                Sx.add(particle);
                Sy.add(particle);
            }
            Sx.sort(new fm3_compare_x_coordinate()); // sort based on increasing coordinates
            Sy.sort(new fm3_compare_y_coordinate()); // sort based on increasing coordinates
            
            // Create a root node "Vact" and the lists Cx(Vact) and Cy(Vact)
            root = new FM3_QuadTreeNode( square_d, Sx, Sy, null );
            
            // Assign a QuadTree object with Vact
            v_act = root;
            
            node_set.add(root); // Add node to the set
            
            if( graph.node_count() > leaf_capacity )
            {
                while( v_act.size() > leaf_capacity )
                {
                    alternating_traversal();
                    // Create a new child-node Vchild of Vact
                    if( v_act.get_Cx().get(0).get_visual_node().getX() < v_act.get_box().getCenterX() )
                        x_min = v_act.get_box().getMinX();
                    else
                        x_min = v_act.get_box().getCenterX();
                    if( v_act.get_Cx().get(0).get_visual_node().getY() < v_act.get_box().getCenterY() )
                        y_min = v_act.get_box().getMinY();
                    else
                        y_min = v_act.get_box().getCenterY();
                    Rectangle2D sub_box = new Rectangle2D( x_min, y_min, v_act.get_box().getWidth()/2.0, v_act.get_box().getHeight()/2.0 );
                    FM3_QuadTreeNode child = new FM3_QuadTreeNode( sub_box, v_act.get_Cx(), v_act.get_Cy(), v_act );
                    v_act.get_children().add(child);
                    
                    if( child.size() > leaf_capacity )
                    {
                        // Shrink(box(Vchild))
                        shrink(child, child.get_box());
                    }
                    else // Mark this as a leaf node
                        leaf_nodes.add(child);
                    node_set.add(child);
                    
                    // Assign Vact with Vchild
                    v_act = child;
                }
                
                // Create new children
                ArrayList<FM3_QuadTreeNode> M = create_child_nodes(leaf_capacity);
                
                ArrayList<FM3_QuadTreeNode> L = new ArrayList<>();
                for( FM3_QuadTreeNode node : M )
                {
                    if( node.size() > leaf_capacity )
                        L.add(node);
                    else // Mark this as a leaf node
                        leaf_nodes.add(node);
                    node_set.add(node);
                }
                
                while(!L.isEmpty())
                {
                    for( FM3_QuadTreeNode node : L )
                    {
                        v_act = node;
                        while( v_act.size() > leaf_capacity )
                        {
                            alternating_traversal();
                            // Create a new child-node Vchild of Vact
                            if( v_act.get_Cx().get(0).get_visual_node().getX() < v_act.get_box().getCenterX() )
                                x_min = v_act.get_box().getMinX();
                            else
                                x_min = v_act.get_box().getCenterX();
                            if( v_act.get_Cx().get(0).get_visual_node().getY() < v_act.get_box().getCenterY() )
                                y_min = v_act.get_box().getMinY();
                            else
                                y_min = v_act.get_box().getCenterY();
                            Rectangle2D sub_box = new Rectangle2D( x_min, y_min, v_act.get_box().getWidth()/2.0, v_act.get_box().getHeight()/2.0 );
                            FM3_QuadTreeNode child = new FM3_QuadTreeNode( sub_box, v_act.get_Cx(), v_act.get_Cy(), v_act );
                            v_act.get_children().add(child);
                            
                            if( child.size() > leaf_capacity )
                            {
                                // Shrink(box(Vchild))
                                shrink(child, child.get_box());
                            }
                            else
                                leaf_nodes.add(child);
                            node_set.add(child);

                            // Assign Vact with Vchild
                            v_act = child;
                        }
                    }
                    //  Create new children
                    M = create_child_nodes(leaf_capacity);
                    
                    L.clear();
                    for( FM3_QuadTreeNode node : M )
                    {
                        if( node.size() > leaf_capacity )
                            L.add(node);
                        else
                            leaf_nodes.add(node);
                        node_set.add(node);
                    }
                }
            }
            else // Mark this as a leaf node
                leaf_nodes.add(root);
        }
        
        // Both Alternating_Traversal methods in one
        private void alternating_traversal()
        {
            // Cx Traversal
            ArrayList<FM3_Node> Cx = v_act.get_Cx();
            ArrayList<FM3_Node> Cy = v_act.get_Cy();
            int left = 0, right = Cx.size()-1;
            double halfbox = v_act.get_box().getCenterX();
            ArrayList<FM3_Node> Cx_left = new ArrayList<>();
            ArrayList<FM3_Node> Cx_right = new ArrayList<>();
            
            boolean traversal_done = false;
            while( !traversal_done )
            {
                if( Cx.get(left).get_visual_node().getX() < halfbox )
                    Cx_left.add(Cx.get(left));
                else if( Cx.get(left).get_visual_node().getX() >= halfbox )
                    Cx_right.add(Cx.get(left));
                
                if( left < right )
                {
                    if( Cx.get(right).get_visual_node().getX() >= halfbox )
                        Cx_right.add(Cx.get(right));
                    else if( Cx.get(right).get_visual_node().getX() < halfbox )
                        Cx_left.add(Cx.get(right));
                }
                
                left++;
                right--;
                if( left > right )
                    traversal_done = true;
            }
            
            String c = "l";
            ArrayList<FM3_Node> M;
            if( Cx_left.size() <= Cx_right.size() )
                M = Cx_left;
            else
            {
                M = Cx_right;
                c = "r";
            }
            
            for( FM3_Node particle : M )
            {
                // Add link to this quadtree-node in Sx and Sy.
                particle.set_S_link(v_act);
                
                // Add index of "left" or "right" to this particle in Sx and Sy.
                particle.set_S_index(c);
                
                // Remove this particle from Cx and Cy.
                Cx.remove(particle);
                Cy.remove(particle);
            }
            
            // Cy Traversal
            int bottom = 0, top = Cy.size()-1;
            halfbox = v_act.get_box().getCenterY();
            ArrayList<FM3_Node> Cy_top = new ArrayList<>();
            ArrayList<FM3_Node> Cy_bottom = new ArrayList<>();
            
            traversal_done = false;
            while( !traversal_done )
            {
                if( Cy.get(bottom).get_visual_node().getY() < halfbox )
                    Cy_bottom.add(Cy.get(bottom));
                else if( Cy.get(bottom).get_visual_node().getY() >= halfbox )
                    Cy_top.add(Cy.get(bottom));
                
                if( bottom < top )
                {
                    if( Cy.get(top).get_visual_node().getY() >= halfbox )
                        Cy_top.add(Cy.get(top));
                    else if( Cy.get(top).get_visual_node().getY() < halfbox )
                        Cy_bottom.add(Cy.get(top));
                }
                
                bottom++;
                top--;
                if( bottom > top )
                    traversal_done = true;
            }
            
            if( Cy_bottom.size() <= Cy_top.size() )
            {
                M = Cy_bottom;
                if( c == "r" )
                    c = "lb";
                else if( c == "l" )
                    c = "rb";
            }
            else
            {
                M = Cy_top;
                if( c == "r" )
                    c = "lt";
                else if( c == "l" )
                    c = "rt";
            }
            
            for( FM3_Node particle : M )
            {
                // Add link to This quadtreenode in Sx and Sy.
                particle.set_S_link(v_act);
                
                // Add index of "left" or "right" to this particle in Sx and Sy.
                particle.set_S_index(c);
                
                // Remove this particle from Cx and Cy.
                Cx.remove(particle);
                Cy.remove(particle);
            }
        }
        
        // Box-Shrinking Technique
        private void shrink( FM3_QuadTreeNode node, Rectangle2D square_d )
        {
            // 1. Let R be the smallest possible RECTANGLE that covers all particles in Vchild
            double rx_min=0.0, ry_min=0.0, rx_max=0.0, ry_max=0.0;
            boolean first = true;
            for( FM3_Node particle : node.get_Cx() )
            {
                if( first )
                {
                    rx_min = particle.get_visual_node().getX();
                    rx_max = particle.get_visual_node().getX();
                    ry_min = particle.get_visual_node().getY();
                    ry_max = particle.get_visual_node().getY();
                    first = false;
                }
                else
                {
                    if( rx_min > particle.get_visual_node().getX() )
                        rx_min = particle.get_visual_node().getX();
                    if( rx_max < particle.get_visual_node().getX() )
                        rx_max = particle.get_visual_node().getX();
                    if( ry_min > particle.get_visual_node().getY() )
                        ry_min = particle.get_visual_node().getY();
                    if( ry_max < particle.get_visual_node().getY() )
                        ry_max = particle.get_visual_node().getY();
                }
            }
            Rectangle2D R = new Rectangle2D( rx_min, ry_min, Math.abs(rx_max-rx_min), Math.abs(ry_max-ry_min) );
            
            // 2. Determine max_subdivisions
            double max_sub=0.0;
            double decomposed_width=square_d.getWidth(),
                    decomposed_xmin=square_d.getMinX(), decomposed_ymin=square_d.getMinY();
            while(decomposed_xmin <= R.getMinX()
                    && decomposed_ymin <= R.getMinY()
                    && (decomposed_xmin+decomposed_width) >= R.getMaxX()
                    && (decomposed_ymin+decomposed_width) >= R.getMaxY())
            {
                max_sub++;
                decomposed_width=square_d.getWidth()/Math.pow(2.0, max_sub);
                if( (decomposed_xmin+decomposed_width) <= R.getMinX() )
                    decomposed_xmin = (decomposed_xmin+decomposed_width);
                if( (decomposed_ymin+decomposed_width) <= R.getMinY() )
                    decomposed_ymin = (decomposed_ymin+decomposed_width);
            }
            if( max_sub != 0.0 )
                max_sub--;
            
            // 3. width(B) = width(D)/2^max_sub
            decomposed_width=square_d.getWidth()/Math.pow(2.0, max_sub);
            
            // 4. xmin(B)  = xmin(D) + Floor((xmin(R)-xmin(D))/width(B)) * width(B)
            // 5. ymin(B)  = ymin(D) + Floor((ymin(R)-ymin(D))/width(B)) * width(B)
            decomposed_xmin = square_d.getMinX() + Math.floor( (R.getMinX()-square_d.getMinX())/decomposed_width ) * decomposed_width;
            decomposed_ymin = square_d.getMinY() + Math.floor( (R.getMinY()-square_d.getMinY())/decomposed_width ) * decomposed_width;
            Rectangle2D B = new Rectangle2D( decomposed_xmin, decomposed_ymin, decomposed_width, decomposed_width );
            
            // 6. box(Vchild) = B
            node.set_box( B );
        }
        
        // Comparator for X coordinate
        private class fm3_compare_x_coordinate implements Comparator<FM3_Node>
        {
            @Override
            public int compare(FM3_Node t1, FM3_Node t2)
            {
                return t1.get_visual_node().getX() < t2.get_visual_node().getX() ? -1 : t1.get_visual_node().getX()==t2.get_visual_node().getX() ? 0 : 1;
            }
        }
        
        // Comparator for Y coordinate
        private class fm3_compare_y_coordinate implements Comparator<FM3_Node>
        {
            @Override
            public int compare(FM3_Node t1, FM3_Node t2)
            {
                return t1.get_visual_node().getY() < t2.get_visual_node().getY() ? -1 : t1.get_visual_node().getY()==t2.get_visual_node().getY() ? 0 : 1;
            }
        }
        
        private ArrayList<FM3_QuadTreeNode> create_child_nodes( int leaf_capacity )
        {
            Map<ArrayList<FM3_Node>,FM3_QuadTreeNode> node_link = new HashMap<>();
            Map<ArrayList<FM3_Node>,String> region_index = new HashMap<>();
            ArrayList<ArrayList<FM3_Node>> Cx_lists = new ArrayList<>();
            ArrayList<ArrayList<FM3_Node>> Cy_lists = new ArrayList<>();
            ArrayList<FM3_QuadTreeNode> newly_created_children = new ArrayList<>();
            
            for( FM3_Node particle : Sx )
            {
                if( particle.get_S_link() != null )
                {
                    FM3_QuadTreeNode link = particle.get_S_link();
                    String index = particle.get_S_index();
                    ArrayList<FM3_Node> existing_list = null;
                    for( ArrayList<FM3_Node> list : Cx_lists )
                    {
                        if( region_index.get(list)!=null
                                && region_index.get(list).equals(index)
                                && node_link.get(list)==link )
                        {
                            existing_list = list;
                            break;
                        }
                    }
                    
                    if(existing_list!=null)
                    {
                        region_index.remove(existing_list);
                        node_link.remove(existing_list);
                        existing_list.add(particle);
                        node_link.put(existing_list, link);
                        region_index.put(existing_list, index);
                    }
                    else // if it's the first time this link+region_index combination (QuadTreeNode+r/l/lt...) has been visited
                    {
                        ArrayList<FM3_Node> temp_Cx_list = new ArrayList<>();
                        temp_Cx_list.add(particle);
                        node_link.put(temp_Cx_list, link);
                        region_index.put(temp_Cx_list, index);
                        Cx_lists.add(temp_Cx_list);
                    }
                }
            }
            // Do the same thing for Sy and Cy lists
            for( FM3_Node particle : Sy )
            {
                if( particle.get_S_link() != null )
                {
                    FM3_QuadTreeNode link = particle.get_S_link();
                    String index = particle.get_S_index();
                    ArrayList<FM3_Node> existing_list = null;
                    for( ArrayList<FM3_Node> list : Cy_lists )
                    {
                        if( region_index.get(list)!=null
                                && region_index.get(list).equals(index)
                                && node_link.get(list)==link )
                        {
                            existing_list = list;
                            break;
                        }
                    }
                    if(existing_list!=null)
                    {
                        region_index.remove(existing_list);
                        node_link.remove(existing_list);
                        existing_list.add(particle);
                        node_link.put(existing_list, link);
                        region_index.put(existing_list, index);
                    }
                    else
                    {
                        ArrayList<FM3_Node> temp_Cy_list = new ArrayList<>();
                        temp_Cy_list.add(particle);
                        node_link.put(temp_Cy_list, link);
                        region_index.put(temp_Cy_list, index);
                        Cy_lists.add(temp_Cy_list);
                    }
                }
            }
            
            // Reinitialize the Sx and Sy elements with "null"
            reinitialize_sx_sy();
            
            // Split the single-char-index ('r' or 'l') lists
            ArrayList<ArrayList<FM3_Node>> temp_Cx_lists = new ArrayList<>();
            ArrayList<ArrayList<FM3_Node>> temp_Cy_lists = new ArrayList<>();
            for( ArrayList<FM3_Node> list : Cx_lists )
            {
                if( region_index.get(list)!=null 
                        && (region_index.get(list).equals("r") || region_index.get(list).equals("l")) )
                {
                    ArrayList<FM3_Node> top = new ArrayList<>();
                    ArrayList<FM3_Node> bottom = new ArrayList<>();
                    String top_index;
                    String bottom_index;
                    if(  region_index.get(list).equals("r") )
                    {
                        top_index = "rt";
                        bottom_index = "rb";
                    }
                    else
                    {
                        top_index = "lt";
                        bottom_index = "lb";
                    }
                    for( FM3_Node particle : list )
                    {
                        if( particle.get_visual_node().getY() < node_link.get(list).get_box().getCenterY() )
                            bottom.add(particle);
                        else
                            top.add(particle);
                    }
                    if( !list.equals(top) )
                    {
                        temp_Cx_lists.add(top);
                        node_link.put(top, node_link.get(list));
                    }
                    if( !list.equals(bottom) )
                    {
                        temp_Cx_lists.add(bottom);
                        node_link.put(bottom, node_link.get(list));
                    }
                    region_index.put(top, top_index);
                    region_index.put(bottom, bottom_index);
                }
            }
            // Add the new lists to the original array
            for( ArrayList<FM3_Node> list : temp_Cx_lists )
                Cx_lists.add(list);
            
            // Do the same splitting for Cy
            for( ArrayList<FM3_Node> list : Cy_lists )
            {
                if( region_index.get(list)!=null 
                        && (region_index.get(list).equals("r") || region_index.get(list).equals("l")) )
                {
                    ArrayList<FM3_Node> top = new ArrayList<>();
                    ArrayList<FM3_Node> bottom = new ArrayList<>();
                    String top_index;
                    String bottom_index;
                    if(  region_index.get(list).equals("r") )
                    {
                        top_index = "rt";
                        bottom_index = "rb";
                    }
                    else
                    {
                        top_index = "lt";
                        bottom_index = "lb";
                    }
                    for( FM3_Node particle : list )
                    {
                        if( particle.get_visual_node().getY() < node_link.get(list).get_box().getCenterY() )
                            bottom.add(particle);
                        else
                            top.add(particle);
                    }
                    if( !list.equals(top) )
                    {
                        temp_Cy_lists.add(top);
                        node_link.put(top, node_link.get(list));
                    }
                    if( !list.equals(bottom) )
                    {
                        temp_Cy_lists.add(bottom);
                        node_link.put(bottom, node_link.get(list));
                    }
                    region_index.put(top, top_index);
                    region_index.put(bottom, bottom_index);
                }
            }
            for( ArrayList<FM3_Node> list : temp_Cy_lists )
                Cy_lists.add(list);
            
            // Create the child nodes for the QuadTree by going through the path created earlier
            for( ArrayList<FM3_Node> list_cx : Cx_lists )
            {
                String index = region_index.get(list_cx);
                FM3_QuadTreeNode node = node_link.get(list_cx);
                
                if( index==null || node==null || index.equals("r") || index.equals("l") || list_cx.size()<=0 )
                    continue;
                // Find corresponding Cy list
                ArrayList<FM3_Node> list_cy = null;
                for( ArrayList<FM3_Node> list2 : Cy_lists )
                {
                    if( region_index.get(list2)!=null
                            && node_link.get(list2)==node
                            && region_index.get(list2).equals(index) )
                    {
                        list_cy = list2;
                        break;
                    }
                }
                // Get the region of the new child node
                Rectangle2D child_box = null;
                if( index.equals("rt") )
                {
                    child_box = new Rectangle2D(node.get_box().getCenterX(),
                            node.get_box().getCenterY(),
                            node.get_box().getWidth()/2.0,
                            node.get_box().getWidth()/2.0);
                }
                else if( index.equals("rb") )
                {
                    child_box = new Rectangle2D(node.get_box().getCenterX(),
                            node.get_box().getMinY(),
                            node.get_box().getWidth()/2.0,
                            node.get_box().getWidth()/2.0);
                }
                else if( index.equals("lb") )
                {
                    child_box = new Rectangle2D(node.get_box().getMinX(),
                            node.get_box().getMinY(),
                            node.get_box().getWidth()/2.0,
                            node.get_box().getWidth()/2.0);
                }
                else if( index.equals("lt") )
                {
                    child_box = new Rectangle2D(node.get_box().getMinX(),
                            node.get_box().getCenterY(),
                            node.get_box().getWidth()/2.0,
                            node.get_box().getWidth()/2.0);
                }
                FM3_QuadTreeNode new_child = new FM3_QuadTreeNode( child_box, list_cx, list_cy, node );
                
                // Box-Shrinking Technique
                if( new_child.size() > leaf_capacity )
                {
                    shrink(new_child, new_child.get_box());
                }
                
                node.get_children().add(new_child);
                newly_created_children.add(new_child);
            }
            return newly_created_children;
        }
        
        private void reinitialize_sx_sy()
        {
            for( FM3_Node particle : Sx )
            {
                particle.clear_S_link_index();
            }
        }
        
        public void print_tree()
        {
            print_tree( root, 0 );
        }
        
        public void print_tree( FM3_QuadTreeNode node, int level )
        {
            for( int i=0 ; i<level ; i++ )
                System.out.print("   ");
            System.out.print(node+" ; Size_"+node.size()+"\n");
            for( FM3_QuadTreeNode child : node.get_children() )
                print_tree( child, level+1 );
        }
        
        public boolean single_node() { return root.get_children().isEmpty(); }
        
        public FM3_QuadTreeNode get_active_node(){ return v_act; }
        public void set_active_node(FM3_QuadTreeNode node) { v_act = node; }
        public FM3_QuadTreeNode get_root(){ return root; }
        public ArrayList<FM3_Node> get_Sx(){ return Sx; }
        public ArrayList<FM3_Node> get_Sy(){ return Sy; }
        public ArrayList<FM3_QuadTreeNode> get_leaf_nodes(){ return leaf_nodes; }
        public ArrayList<FM3_QuadTreeNode> get_nodes(){ return node_set; }
        
        private final FM3_QuadTreeNode root;
        private FM3_QuadTreeNode v_act;
        private ArrayList<FM3_Node> Sx = new ArrayList<>();
        private ArrayList<FM3_Node> Sy = new ArrayList<>();
        private final ArrayList<FM3_QuadTreeNode> leaf_nodes = new ArrayList<>();
        private final ArrayList<FM3_QuadTreeNode> node_set = new ArrayList<>();
    }
    
    // The QuadTree node class
    private class FM3_QuadTreeNode
    {
        public FM3_QuadTreeNode( Rectangle2D box_param, ArrayList<FM3_Node> Cx_param, ArrayList<FM3_Node> Cy_param, FM3_QuadTreeNode p )
        {
            box = box_param;
            Cx = (ArrayList<FM3_Node>) Cx_param.clone();
            Cy = (ArrayList<FM3_Node>) Cy_param.clone();
            parent = p;
            calculate_sm_and_lg();
        }
        
        public void calculate_Mp( int precision )
        {
            if( children.isEmpty() ) // LeafNode
            {
                double charge_x = 0.0;
                double charge_y = 0.0;
                if( is_collapsed )
                {
                    for( FM3_Node particle : Cx_collapsed )
                    {
                        charge_x++;
                    }
                }
                else
                {
                    for( FM3_Node particle : Cx )
                    {
                        charge_x++;
                    }
                }
                Mp_coef_x.add(charge_x);
                Mp_coef_y.add(charge_y);
                Point2D z0 = new Point2D( Sm.getCenterX(), Sm.getCenterY() );
                
                for( int k=1 ; k<=precision ; k++ )
                {
                    Point2D dist;
                    Point2D coef = new Point2D(0.0,0.0);
                    double coef_x;
                    double coef_y;
                    for( FM3_Node particle : Cx )
                    {
                        dist = new Point2D( (particle.get_visual_node().getX()-z0.getX()), (particle.get_visual_node().getY()-z0.getY()) );
                        coef = complex_add( coef, complex_divide( complex_multiply( complex_pow(dist,k), (-1.0) ), (double)k ) );
                    }
                    coef_x = coef.getX();
                    coef_y = coef.getY();
                    Mp_coef_x.add(coef_x);
                    Mp_coef_y.add(coef_y);
                }
            }
            else // Interior node
            {
                for( FM3_QuadTreeNode child : children )
                {
                    Point2D z1 = new Point2D( Sm.getCenterX(), Sm.getCenterY() );
                    Point2D z0 = new Point2D( child.get_Sm().getCenterX(), child.get_Sm().getCenterY() );
                    Point2D dist = new Point2D( z0.subtract(z1).getX(), z0.subtract(z1).getY() );
                    
                    if( Mp_coef_x.isEmpty() )
                    {
                        Mp_coef_x.add(child.get_mp_coef_x().get(0));
                        Mp_coef_y.add(child.get_mp_coef_y().get(0));
                    }
                    else
                    {
                        Mp_coef_x.set(0, Mp_coef_x.get(0)+child.get_mp_coef_x().get(0));
                        Mp_coef_y.set(0, Mp_coef_y.get(0)+child.get_mp_coef_y().get(0));
                    }
                    
                    for( int l=1 ; l<=precision ; l++ )
                    {
                        double coef_x=0.0, coef_y=0.0;
                        Point2D child_coef = new Point2D( child.get_mp_coef_x().get(0), child.get_mp_coef_y().get(0) );
                        Point2D coef = complex_divide( complex_multiply( complex_multiply( child_coef, complex_pow( dist, l ) ), (-1.0) ), l );
                        int bc;
                        for( int k=1 ; k<=l ; k++ )
                        {
                            bc = binomial_coefficient( (l-1), (k-1) );
                            child_coef = new Point2D( child.get_mp_coef_x().get(k), child.get_mp_coef_y().get(k) );
                            coef = complex_add( coef, complex_multiply( child_coef, complex_multiply( complex_pow( dist, (l-k) ), bc ) ) );
                        }
                        coef_x = coef.getX();
                        coef_y = coef.getY();
                        
                        if( Mp_coef_x.size() <= l )
                        {
                            Mp_coef_x.add(coef_x);
                            Mp_coef_y.add(coef_y);
                        }
                        else
                        {
                            Mp_coef_x.set(l, Mp_coef_x.get(l)+coef_x);
                            Mp_coef_y.set(l, Mp_coef_y.get(l)+coef_y);
                        }
                    }
                }
            }
            Mp_coef_calculated = true;
        }
        
        public void collapse()
        {
            for( FM3_Node particle : Cx )
                Cx_collapsed.add(particle);
            for( FM3_Node particle : Cy )
                Cy_collapsed.add(particle);
            FM3_Node group_particle = Cx_collapsed.get(0);
            for( FM3_Node particle : Cx_collapsed )
            {
                Cx.remove(particle);
                Cy.remove(particle);
            }
            Cx.add(group_particle);
            Cy.add(group_particle);
            is_collapsed = true;
        }
        
        public int size() { return Cx.size(); }
        public Rectangle2D get_box() { return box; }
        public Rectangle2D get_Sm() { return Sm; }
        public Rectangle2D get_Lg() { return Lg; }
        public ArrayList<FM3_Node> get_Cx() { return Cx; }
        public ArrayList<FM3_Node> get_Cy() { return Cy; }
        public ArrayList<FM3_Node> get_Cx_collapsed() { return Cx_collapsed; }
        public ArrayList<FM3_Node> get_Cy_collapsed() { return Cy_collapsed; }
        public ArrayList<FM3_QuadTreeNode> get_children() { return children; }
        public void set_box( Rectangle2D new_box ) { box = new_box; }
        public FM3_QuadTreeNode get_parent() { return parent; }
        public boolean is_mp_coef_calculated() { return Mp_coef_calculated; }
        public boolean is_lp_coef_calculated() { return Lp_coef_calculated; }
        public void set_lp_coef_calculated(boolean bool){ Lp_coef_calculated = bool; }
        public ArrayList<Double> get_mp_coef_x() { return Mp_coef_x; }
        public ArrayList<Double> get_mp_coef_y() { return Mp_coef_y; }
        public ArrayList<Double> get_lp_coef_x() { return Lp_coef_x; }
        public ArrayList<Double> get_lp_coef_y() { return Lp_coef_y; }
        private void calculate_sm_and_lg()
        {
            if( Cx.size() == 1 )
                Sm = new Rectangle2D( Cx.get(0).get_visual_node().getX(), Cx.get(0).get_visual_node().getY(), 0.0, 0.0 );
            else
            {
                // 1. Let R be the smallest possible RECTANGLE that covers all particles in Vchild
                double rx_min=0.0, ry_min=0.0, rx_max=0.0, ry_max=0.0;
                boolean first = true;
                for( FM3_Node particle : Cx )
                {
                    if( first )
                    {
                        rx_min = particle.get_visual_node().getX();
                        rx_max = particle.get_visual_node().getX();
                        ry_min = particle.get_visual_node().getY();
                        ry_max = particle.get_visual_node().getY();
                        first = false;
                    }
                    else
                    {
                        if( rx_min > particle.get_visual_node().getX() )
                            rx_min = particle.get_visual_node().getX();
                        if( rx_max < particle.get_visual_node().getX() )
                            rx_max = particle.get_visual_node().getX();
                        if( ry_min > particle.get_visual_node().getY() )
                            ry_min = particle.get_visual_node().getY();
                        if( ry_max < particle.get_visual_node().getY() )
                            ry_max = particle.get_visual_node().getY();
                    }
                }
                Rectangle2D R = new Rectangle2D( rx_min, ry_min, Math.abs(rx_max-rx_min), Math.abs(ry_max-ry_min) );
                
                // Exception Handling, if Sm() is a point and contains >1 particles
                if( Cx.size()>1 && R.getHeight()<1 && R.getWidth()<1 )
                {
                    collapse();
                    Rectangle2D B = new Rectangle2D( Cx.get(0).get_visual_node().getX(), Cx.get(0).get_visual_node().getY(), 0.0, 0.0 );
                    
                    // 6. Sm = B
                    Sm = B;
                }
                else
                {
                    // 2. Determine max_subdivisions
                    double max_sub=0.0;
                    double decomposed_width=box.getWidth(),
                            decomposed_xmin=box.getMinX(), decomposed_ymin=box.getMinY();
                    
                    while(decomposed_xmin <= R.getMinX()
                            && decomposed_ymin <= R.getMinY()
                            && (decomposed_xmin+decomposed_width) >= R.getMaxX()
                            && (decomposed_ymin+decomposed_width) >= R.getMaxY())
                    {
                        max_sub++;
                        decomposed_width=box.getWidth()/Math.pow(2.0, max_sub);
                        if( (decomposed_xmin+decomposed_width) <= R.getMinX() )
                            decomposed_xmin = (decomposed_xmin+decomposed_width);
                        if( (decomposed_ymin+decomposed_width) <= R.getMinY() )
                            decomposed_ymin = (decomposed_ymin+decomposed_width);
                    }
                    if( max_sub != 0.0 )
                        max_sub--;
                    
                    // 3. width(B) = width(D)/2^max_sub
                    decomposed_width=box.getWidth()/Math.pow(2.0, max_sub);
                    
                    // 4. xmin(B)  = xmin(D) + Floor((xmin(R)-xmin(D))/width(B)) * width(B)
                    // 5. ymin(B)  = ymin(D) + Floor((ymin(R)-ymin(D))/width(B)) * width(B)
                    decomposed_xmin = box.getMinX() + Math.floor( (R.getMinX()-box.getMinX())/decomposed_width ) * decomposed_width;
                    decomposed_ymin = box.getMinY() + Math.floor( (R.getMinY()-box.getMinY())/decomposed_width ) * decomposed_width;
                    Rectangle2D B = new Rectangle2D( decomposed_xmin, decomposed_ymin, decomposed_width, decomposed_width );
                    
                    // 6. Sm = B
                    Sm = B;
                }
            }
            if( parent == null ) // Tree's root
                Lg = Sm;
            else
            {
                Rectangle2D parent_sm = parent.get_Sm();
                double decomposed_width=parent_sm.getWidth()/2.0,
                        decomposed_xmin=parent_sm.getMinX(), decomposed_ymin=parent_sm.getMinY();
                if( (decomposed_xmin+decomposed_width) <= Sm.getMinX() )
                    decomposed_xmin = (decomposed_xmin+decomposed_width);
                if( (decomposed_ymin+decomposed_width) <= Sm.getMinY() )
                    decomposed_ymin = (decomposed_ymin+decomposed_width);
                Rectangle2D B = new Rectangle2D( decomposed_xmin, decomposed_ymin, decomposed_width, decomposed_width );
                Lg = B;
            }
        }
        private ArrayList<FM3_QuadTreeNode> get_I() { return I; }
        private ArrayList<FM3_QuadTreeNode> get_R() { return R; }
        private ArrayList<FM3_QuadTreeNode> get_D1() { return D1; }
        private ArrayList<FM3_QuadTreeNode> get_D2() { return D2; }
        private ArrayList<FM3_QuadTreeNode> get_D3() { return D3; }
        private ArrayList<FM3_QuadTreeNode> get_K() { return K; }
        
        private Rectangle2D box;
        private Rectangle2D Sm;
        private Rectangle2D Lg;
        private final ArrayList<FM3_Node> Cx;
        private final ArrayList<FM3_Node> Cy;
        private final ArrayList<FM3_Node> Cx_collapsed = new ArrayList<>();
        private final ArrayList<FM3_Node> Cy_collapsed = new ArrayList<>();
        private boolean is_collapsed = false;
        private final ArrayList<FM3_QuadTreeNode> children = new ArrayList<>();
        private FM3_QuadTreeNode parent = null;
        
        private boolean Mp_coef_calculated = false;
        private final ArrayList<Double> Mp_coef_x = new ArrayList<>();
        private final ArrayList<Double> Mp_coef_y = new ArrayList<>();
        
        private boolean Lp_coef_calculated = false;
        private final ArrayList<Double> Lp_coef_x = new ArrayList<>();
        private final ArrayList<Double> Lp_coef_y = new ArrayList<>();
        
        private final ArrayList<FM3_QuadTreeNode> I = new ArrayList<>();
        private final ArrayList<FM3_QuadTreeNode> R = new ArrayList<>();
        private final ArrayList<FM3_QuadTreeNode> D1 = new ArrayList<>();
        private final ArrayList<FM3_QuadTreeNode> D2 = new ArrayList<>();
        private final ArrayList<FM3_QuadTreeNode> D3 = new ArrayList<>();
        private final ArrayList<FM3_QuadTreeNode> K = new ArrayList<>();
    }
    
    private boolean overlap( Rectangle2D box1, Rectangle2D box2 )
    {
        if( box1.intersects(box2) || box2.intersects(box1) )
        {
            return true;
        }
        else if( box1.getMinX() == box2.getMinX()
                && box1.getMaxX() == box2.getMaxX()
                && box1.getMaxY() == box2.getMaxY()
                && box1.getMinY() == box2.getMinY() )
            return true;
        return false;
    }
    
    private boolean neighbors( Rectangle2D box1, Rectangle2D box2 )
    {
        // Return whether the regions are neighbors or not
        if( overlap( box1, box2 ) )
            return false;
        ArrayList<Point2D> box1_corners = new ArrayList<>();
        box1_corners.add( new Point2D(box1.getMinX(),box1.getMinY()) );
        box1_corners.add( new Point2D(box1.getMinX(),box1.getMaxY()) );
        box1_corners.add( new Point2D(box1.getMaxX(),box1.getMinY()) );
        box1_corners.add( new Point2D(box1.getMaxX(),box1.getMaxY()) );
        
        for( Point2D corner : box1_corners )
        {
            if( box2.contains(corner) )
                return true;
        }
        return false;
    }
    private boolean well_separated( FM3_QuadTreeNode node1, FM3_QuadTreeNode node2 )
    {
        if( node1.get_Sm().getWidth() >= node2.get_Sm().getWidth() )
        {
            if( well_separated( node1.get_Sm(), cover_region(node2,node1) ) )
                return true;
            else
                return false;
        }
        
        if( node1.get_Sm().getWidth() < node2.get_Sm().getWidth() )
        {
            if( well_separated( node2.get_Sm(), cover_region(node1,node2) ) )
                return true;
            else
                return false;
        }
        
        return false;
    }
    private boolean well_separated( Rectangle2D box1, Rectangle2D box2 )
    {
        return ( !neighbors(box1, box2) && !overlap(box1, box2) );
    }
    
    private Rectangle2D cover_region( FM3_QuadTreeNode node1, FM3_QuadTreeNode node2 )
    {
        /*
        This function returns the region of the same size as node2's Sm-Region
        and that covers node1's Sm-Region. This function assumes node2's
        Sm-Region is >= to node1's Sm-Region.
        */
        if( node1.get_Sm().getWidth() == node2.get_Sm().getWidth() )
            return node1.get_Sm();
        
        // Get the root's Sm-Region
        FM3_QuadTreeNode parent = node2;
        while( parent.get_parent()!=null )
            parent = parent.get_parent();
        double space_width = parent.get_Sm().getWidth();
        double space_minx = parent.get_Sm().getMinX();
        double space_miny = parent.get_Sm().getMinY();
        
        // Find the cover-region of the same size as node2's Sm-Region.
        while( space_width != node2.get_Sm().getWidth() )
        {
            // Split the possible space's height & width in half
            space_width = space_width/2.0;
            
            // Re-Arrange to cover node1's Sm-Region.
            if( space_minx + space_width -0.1 <= node1.get_Sm().getMinX() )
                space_minx = space_minx + space_width;
            if( space_miny + space_width -0.1 <= node1.get_Sm().getMinY() )
                space_miny = space_miny + space_width;
        }
        
        // Return the cover-region
        Rectangle2D cover = new Rectangle2D( space_minx, space_miny, space_width, space_width );
        return cover;
    }
    
    private Point2D complex_add( Point2D complex_1, Point2D complex_2 )
    {
        double re, im;
        re = complex_1.getX()+complex_2.getX();
        im = complex_1.getY()+complex_2.getY();
        return new Point2D( re, im );
    }
    private Point2D complex_multiply( Point2D complex_1, Point2D complex_2 )
    {
        double re, im;
        re = (complex_1.getX()*complex_2.getX()) - (complex_1.getY()*complex_2.getY());
        im = (complex_1.getX()*complex_2.getY()) + (complex_1.getY()*complex_2.getX());
        return new Point2D( re, im );
    }
    private Point2D complex_multiply( Point2D complex, double real )
    {
        double re, im;
        re = complex.getX()*real;
        im = complex.getY()*real;
        return new Point2D( re, im );
    }
    private Point2D complex_pow( Point2D complex, int pow )
    {
        if( pow == 0 )
            return new Point2D( 1.0, 0.0 );
        
        double current_re=complex.getX(), current_im=complex.getY();
        double new_re, new_im;
        for( int i=1 ; i<pow ; i++ )
        {
            new_re = (current_re*complex.getX())-(current_im*complex.getY());
            new_im = (current_re*complex.getY())+(current_im*complex.getX());
            current_re = new_re;
            current_im = new_im;
        }
        return new Point2D( current_re, current_im );
    }
    private Point2D complex_divide( Point2D complex_1, Point2D complex_2 )
    {
        // Takes the first complex number divided by the second
        double re, im;
        Point2D conjugate = new Point2D( complex_2.getX(), ((-1)*complex_2.getY()) );
        Point2D denominator = complex_multiply( complex_2, conjugate );
        Point2D numerator = complex_multiply( complex_1, conjugate );
        if( denominator.getX() != 0.0 )
        {
            re = numerator.getX()/denominator.getX();
            im = numerator.getY()/denominator.getX();
            return new Point2D( re, im );
        }
        else
            return new Point2D( 0.0, 0.0 );
    }
    private Point2D complex_divide( double real, Point2D complex_2 )
    {
        // Takes the real number divided by the complex number
        double re, im;
        Point2D conjugate = new Point2D( complex_2.getX(), ((-1)*complex_2.getY()) );
        Point2D denominator = complex_multiply( complex_2, conjugate );
        Point2D numerator = complex_multiply( conjugate, real );
        if( denominator.getX() != 0.0 )
        {
            re = numerator.getX()/denominator.getX();
            im = numerator.getY()/denominator.getX();
            return new Point2D( re, im );
        }
        else
            return new Point2D( 0.0, 0.0 );
    }
    private Point2D complex_divide( Point2D complex_2, double real )
    {
        // Takes the complex number divided by the real number
        double re, im;
        if( real != 0.0 )
        {
            re = complex_2.getX() / real;
            im = complex_2.getY() / real;
            return new Point2D( re, im );
        }
        else
            return new Point2D( 0.0, 0.0 );
    }
    private Point2D complex_log( double base, Point2D complex )
    {
        double re, im;
        re = Math.log( Math.sqrt(Math.pow(complex.getX(),2)+Math.pow(complex.getY(),2)) )/Math.log(base);
        im = Math.atan2(complex.getY(), complex.getX())/Math.log(base);
        return new Point2D( re, im );
    }
    private double complex_norm( Point2D complex )
    {
        double norm = Math.sqrt(Math.pow(complex.getX(),2)+Math.pow(complex.getY(),2));
        return norm;
    }
    
    private int binomial_coefficient( int n, int k )
    {
        int value = 1;
        if( n != k && k != 0 )
        {
            for( int i=0 ; i<k ; i++ )
                value = value * (n-i)/(k-i);
        }
        return value;
    }
    
    private  void fm3_multipole_framework( FM3_Graph graph, FM3_QuadTree tree, int precision )
    {
        // Part1, Trivial Case & Initializations
        if( tree.single_node() )
        {
            // Make a call to "calculate_repulsion_forces()" and EXIT
            fm3_calculate_repulsion_forces(graph);
            return;
        }
        
        // Part2, Bottom-Up Traversal
        // Foreach LeafNode: calculate the coefficients of Mp, due to all particles contained in the Sm-region.
        for( FM3_QuadTreeNode node : tree.get_leaf_nodes() )
        {
            node.calculate_Mp(precision);
        }
        
        // Calculate the Mp-Coefficients of the interior nodes
        for( FM3_QuadTreeNode node : tree.get_leaf_nodes() )
        {
            tree.set_active_node(node);
            while( tree.get_active_node() != tree.get_root() )
            {
                FM3_QuadTreeNode parent = tree.get_active_node().get_parent();
                tree.set_active_node( parent );
                if( tree.get_active_node().is_mp_coef_calculated() )
                    continue;
                
                // Detect if all children have been calculated
                boolean mp_coef_calculated = true;
                for( FM3_QuadTreeNode child : tree.get_active_node().get_children() )
                {
                    if( !child.is_mp_coef_calculated() )
                    {
                        mp_coef_calculated = false;
                        break;
                    }
                }
                if( mp_coef_calculated )
                    tree.get_active_node().calculate_Mp(precision);
                else
                    break;
            }
        }
        
        // Part3, Top-Down Traversal
        // Foreach child of the ROOT: "Calculate_Local_Expansions_and_Node_Sets()"
        for( FM3_QuadTreeNode child : tree.get_root().get_children() )
        {
            fm3_calculate_local_expansions_and_node_sets( tree, child, precision );
        }
        
        // Part4, Obtain The Forces
        
        
        //          Have a set (C) of particles contained in the Sm-region.
        //          Calculate Force_Local using coefficients of Lp.
        //          Calculate Force_Direct using "D1-UNION-D3-UNION-C".
        //          Calculate Force_Multipole using K.
        //          Force_Repulsive = Force_Local + Force_Direct + Force_Multipole
        for( FM3_QuadTreeNode node : tree.get_leaf_nodes() )
        {
            // Obtain forces for each particle
            for( FM3_Node particle : node.get_Cx() )
            {
                // Calculate Force_Local[]
                Point2D local_z  = new Point2D(particle.get_visual_node().getX(),particle.get_visual_node().getY());
                Point2D local_z1 = new Point2D(node.get_Sm().getCenterX(),node.get_Sm().getCenterY());
                double local_sumx;
                double local_sumy;
                Point2D lp_dist = new Point2D( (local_z.getX()-local_z1.getX()), (local_z.getY()-local_z1.getY()) );
                Point2D lp_coef;
                Point2D local_sum = new Point2D(0.0,0.0);
                for( int l=1 ; l<=precision ; l++ )
                {
                    if( node.get_lp_coef_x().size() == precision+1 )
                    {
                        lp_coef = new Point2D( node.get_lp_coef_x().get(l), node.get_lp_coef_y().get(l) );
                        local_sum = complex_add( local_sum, complex_multiply( complex_multiply( lp_coef, complex_pow(lp_dist,(l-1)) ), (double)l ) );
                    }
                }
                local_sumx = local_sum.getX();
                local_sumy = (-1.0) * local_sum.getY();
                
                // Calculate Force_Direct[]
                double direct_sum_x = 0.0;
                double direct_sum_y = 0.0;
                for( FM3_Node other_particle : node.get_Cx() ) // This node's own particles
                {
                    if( particle == other_particle )
                        continue;
                    double distance_x = particle.get_visual_node().getX() - other_particle.get_visual_node().getX();
                    double distance_y = particle.get_visual_node().getY() - other_particle.get_visual_node().getY();
                    Point2D node1 = new Point2D(particle.get_visual_node().getX(),particle.get_visual_node().getY());
                    Point2D node2 = new Point2D(other_particle.get_visual_node().getX(),other_particle.get_visual_node().getY());
                    double distance = node1.distance(node2);
                    if( distance != 0 )
                    {
                        double temp_force = 1/distance;
                        direct_sum_x = direct_sum_x + (distance_x / distance) * temp_force;
                        direct_sum_y = direct_sum_y + (distance_y / distance) * temp_force;
                    }
                }
                for( FM3_QuadTreeNode other_node : node.get_D1() ) // Particles of nodes in set D1
                {
                    for( FM3_Node other_particle : other_node.get_Cx() )
                    {
                        double distance_x = particle.get_visual_node().getX() - other_particle.get_visual_node().getX();
                        double distance_y = particle.get_visual_node().getY() - other_particle.get_visual_node().getY();
                        Point2D node1 = new Point2D(particle.get_visual_node().getX(),particle.get_visual_node().getY());
                        Point2D node2 = new Point2D(other_particle.get_visual_node().getX(),other_particle.get_visual_node().getY());
                        double distance = node1.distance(node2);
                        if( distance != 0 )
                        {
                            double temp_force = 1/distance;
                            direct_sum_x = direct_sum_x + (distance_x / distance) * temp_force;
                            direct_sum_y = direct_sum_y + (distance_y / distance) * temp_force;
                        }
                    }
                }
                for( FM3_QuadTreeNode other_node : node.get_D3() ) // Particles of nodes in set D3
                {
                    for( FM3_Node other_particle : other_node.get_Cx() )
                    {
                        double distance_x = particle.get_visual_node().getX() - other_particle.get_visual_node().getX();
                        double distance_y = particle.get_visual_node().getY() - other_particle.get_visual_node().getY();
                        Point2D node1 = new Point2D(particle.get_visual_node().getX(),particle.get_visual_node().getY());
                        Point2D node2 = new Point2D(other_particle.get_visual_node().getX(),other_particle.get_visual_node().getY());
                        double distance = node1.distance(node2);
                        if( distance != 0 )
                        {
                            double temp_force = 1/distance;
                            direct_sum_x = direct_sum_x + (distance_x / distance) * temp_force;
                            direct_sum_y = direct_sum_y + (distance_y / distance) * temp_force;
                        }
                    }
                }
                
                // Calculate Force_Multipole[]
                Point2D multipole_z  = new Point2D(particle.get_visual_node().getX(),particle.get_visual_node().getY());
                double multipole_sum_x;
                double multipole_sum_y;
                Point2D mp_dist;
                Point2D multipole_sum = new Point2D(0.0,0.0);
                Point2D other_node_coef;
                for( FM3_QuadTreeNode other_node : node.get_K() )
                {
                    if( other_node != node )
                    {
                        Point2D multipole_z0 = new Point2D(other_node.get_Sm().getCenterX(),other_node.get_Sm().getCenterY());
                        mp_dist = new Point2D( (multipole_z.getX()-multipole_z0.getX()), (multipole_z.getY()-multipole_z0.getY()) );
                        other_node_coef = new Point2D( other_node.get_mp_coef_x().get(0), other_node.get_mp_coef_y().get(0) );
                        multipole_sum = complex_add( multipole_sum, complex_divide( other_node_coef, mp_dist ) );
                        for( int k=1 ; k<=precision ; k++ )
                        {
                            other_node_coef = new Point2D( other_node.get_mp_coef_x().get(k), other_node.get_mp_coef_y().get(k) );
                            multipole_sum = complex_add( multipole_sum, complex_multiply( 
                                    complex_divide(complex_multiply(other_node_coef,(double)k), complex_pow( mp_dist, (k+1))), (-1.0) ) );
                        }
                    }
                }
                multipole_sum_x = multipole_sum.getX();
                multipole_sum_y = (-1.0) * multipole_sum.getY();
                
                // Calculate Force_Repulsive[]
                double result_x = local_sumx + direct_sum_x + multipole_sum_x;
                double result_y = local_sumy + direct_sum_y + multipole_sum_y;
                particle.clear_repulsion_force();
                particle.add_repulsion_force(result_x, result_y);
            }
            
            // Exception handling
            if( node.is_collapsed )
            {
                FM3_Node group_particle = node.get_Cx().get(0);
                
                // Each collapsed particle is assigned the same forces affecting the group_particle
                for( FM3_Node particle : node.get_Cx_collapsed() )
                {
                    double result_x = group_particle.get_repulsion_force_x();
                    double result_y = group_particle.get_repulsion_force_y();
                    
                    // Separate the particles with random force-vectors
                    Random rand = new Random();
                    if( rand.nextInt(2)==0 )
                        result_x = result_x + 2.0;
                    else
                        result_x = result_x - 2.0;
                    if( rand.nextInt(2)==0 )
                        result_y = result_y + 2.0;
                    else
                        result_y = result_y - 2.0;
                    
                    particle.clear_repulsion_force();
                    particle.add_repulsion_force(result_x, result_y);
                }
            }
        }
    }
    
    private void fm3_calculate_local_expansions_and_node_sets( FM3_QuadTree T, FM3_QuadTreeNode node, int precision )
    {
        // Part 3.1 ( Find sets R(v), I(v), D1(v), D2(v) )
        ArrayList<FM3_QuadTreeNode> E = new ArrayList<>();
        if( node.get_parent() == T.get_root() )
            E.add(node.get_parent());
        else
        {
            for( FM3_QuadTreeNode add_node : node.get_parent().get_R() )
                E.add(add_node);
            for( FM3_QuadTreeNode add_node : node.get_parent().get_D1() )
            {
                if( !E.contains(add_node) )
                    E.add(add_node);
            }
        }
        while( !E.isEmpty() )
        {
            FM3_QuadTreeNode temp_node = E.get(0);
            if( well_separated(node,temp_node) )
            {
                node.get_I().add(temp_node);
            }
            else if( node.get_Sm().getWidth() >= temp_node.get_Sm().getWidth() )
            {
                node.get_R().add(temp_node);
            }
            else if( !temp_node.get_children().isEmpty() )
            {
                for( FM3_QuadTreeNode child : temp_node.get_children() )
                {
                    E.add(child);
                }
            }
            else if( neighbors(node.get_Sm(), temp_node.get_Sm()) )
            {
                node.get_D1().add(temp_node);
            }
            else
            {
                node.get_D2().add(temp_node);
            }
            E.remove(temp_node);
        }
        
        // Part 3.2 ( Calculate the coefficients of Lp )
        for( FM3_QuadTreeNode x : node.get_I() )
        {
            fm3_calulate_and_add_Lp(precision,x,node);
        }
        for( FM3_QuadTreeNode x : node.get_D2() )
        {
            fm3_calulate_and_add_Lp_of_leaf(precision,x,node);
        }
        if( node.get_parent().is_lp_coef_calculated() )
        {
            fm3_calculate_and_add_shifted_Lp(precision,node);
        }
        
        // Part 3.3 ( Find D3(v), K(v) for leafNodes )
        if( node.get_children().isEmpty() ) // node is a LeafNode
        {
            E = (ArrayList<FM3_QuadTreeNode>) node.get_R().clone();
            while( !E.isEmpty() )
            {
                FM3_QuadTreeNode temp_node = E.get(0);
                if( !neighbors(node.get_Sm(), temp_node.get_Sm()) )
                {
                    node.get_K().add(temp_node);
                }
                else if( neighbors(node.get_Sm(), temp_node.get_Sm())
                        && temp_node.get_children().isEmpty() )
                {
                    node.get_D3().add(temp_node);
                }
                else
                {
                    for( FM3_QuadTreeNode child : temp_node.get_children() )
                    {
                        E.add(child);
                    }
                }
                E.remove(temp_node);
            }
        }
        
        // Part 3.4 ( Recursion )
        //   Re-Run this function foreach child of v, if v!=LeafNode
        if( !node.get_children().isEmpty() )
        {
            for( FM3_QuadTreeNode child : node.get_children() )
                fm3_calculate_local_expansions_and_node_sets( T, child, precision );
        }
    }
    
    // Converts interaction_node's Mp_coefficients to Lp_coefficients and then adds these to add_to_node's Lp_coefficients
    private void fm3_calulate_and_add_Lp( int precision, FM3_QuadTreeNode interaction_node, FM3_QuadTreeNode add_to_node )
    {
        if( !add_to_node.is_lp_coef_calculated() )
        {
            for( int i=0 ; i<=precision ; i++ )
            {
                add_to_node.get_lp_coef_x().add(0.0);
                add_to_node.get_lp_coef_y().add(0.0);
            }
            add_to_node.set_lp_coef_calculated(true);
        }
        
        Point2D z0 = new Point2D(interaction_node.get_Sm().getCenterX(), interaction_node.get_Sm().getCenterY());
        Point2D z1 = new Point2D(add_to_node.get_Sm().getCenterX(), add_to_node.get_Sm().getCenterY());
        Point2D dist = new Point2D( z1.getX()-z0.getX(), z1.getY()-z0.getY() );
        int bc;
        
        for( int l=0 ; l<=precision ; l++ )
        {
            double sumx=0.0, sumy=0.0;
            Point2D sum = new Point2D( 0.0, 0.0 );
            Point2D interaction_node_mp;
            if( l==0 )
            {
                interaction_node_mp = new Point2D( interaction_node.get_mp_coef_x().get(0), interaction_node.get_mp_coef_y().get(0) );
                if( dist.getX()!=0.0 || dist.getY()!=0.0 )
                {
                    sum = complex_multiply( interaction_node_mp, complex_log( 10, dist ) );
                }
                for( int k=1 ; k<=precision ; k++ )
                {
                    interaction_node_mp = new Point2D( interaction_node.get_mp_coef_x().get(k), interaction_node.get_mp_coef_y().get(k) );
                    sum = complex_add( sum, complex_divide( interaction_node_mp, complex_pow( dist, k ) ) );
                }
                sumx = sum.getX();
                sumy = sum.getY();
            }
            else
            {
                interaction_node_mp = new Point2D( interaction_node.get_mp_coef_x().get(0), interaction_node.get_mp_coef_y().get(0) );
                sum = complex_divide( complex_multiply( interaction_node_mp, Math.pow((-1),(l+1)) ),
                        complex_multiply( complex_pow(dist,l), l ) );
                Point2D factor = complex_pow( complex_divide(1.0,dist), l );
                Point2D sum_2 = new Point2D( 0.0, 0.0 );
                for( int k=1 ; k<=precision ; k++ )
                {
                    bc = binomial_coefficient( (l+k-1), (k-1) );
                    interaction_node_mp = new Point2D( interaction_node.get_mp_coef_x().get(k), interaction_node.get_mp_coef_y().get(k) );
                    sum_2 = complex_add( sum_2, complex_divide( complex_multiply( interaction_node_mp, bc ), complex_pow(dist,k) ) );
                }
                sum = complex_add( sum, complex_multiply( sum_2, factor ) );
                sumx = sum.getX();
                sumy = sum.getY();
            }
            add_to_node.get_lp_coef_x().set(l, add_to_node.get_lp_coef_x().get(l)+sumx);
            add_to_node.get_lp_coef_y().set(l, add_to_node.get_lp_coef_y().get(l)+sumy);
        }
    }
    
    // Coefficients of Lp for leafs
    private void fm3_calulate_and_add_Lp_of_leaf( int precision, FM3_QuadTreeNode interaction_node, FM3_QuadTreeNode add_to_node )
    {
        double mp_particle = 1.0;
        if( !add_to_node.is_lp_coef_calculated() )
        {
            for( int i=0 ; i<=precision ; i++ )
            {
                add_to_node.get_lp_coef_x().add(0.0);
                add_to_node.get_lp_coef_y().add(0.0);
            }
            add_to_node.set_lp_coef_calculated(true);
        }
        
        for( FM3_Node particle : interaction_node.get_Cx() )
        {
            Point2D z0 = new Point2D(particle.get_visual_node().getX(), particle.get_visual_node().getY());
            Point2D z1 = new Point2D(add_to_node.get_Sm().getCenterX(), add_to_node.get_Sm().getCenterY());
            Point2D dist = new Point2D( z1.getX()-z0.getX(), z1.getY()-z0.getY() );
            for( int l=0 ; l<=precision ; l++ )
            {
                double sumx=0.0, sumy=0.0;
                Point2D sum;
                if( l==0 )
                {
                    sum = complex_multiply( complex_log( 10, dist ), mp_particle );
                    sumx = sum.getX();
                    sumy = sum.getY();
                }
                else
                {
                    sum = complex_divide( (Math.pow((-1),(l+1))*mp_particle),
                            complex_multiply( complex_pow(dist,l), l ) );
                    sumx = sum.getX();
                    sumy = sum.getY();
                }
                add_to_node.get_lp_coef_x().set(l, add_to_node.get_lp_coef_x().get(l)+sumx);
                add_to_node.get_lp_coef_y().set(l, add_to_node.get_lp_coef_y().get(l)+sumy);
            }
        }
    }
    
    // Coefficients of Lp for parent
    private void fm3_calculate_and_add_shifted_Lp( int precision, FM3_QuadTreeNode add_to_node )
    {
        if( !add_to_node.is_lp_coef_calculated() )
        {
            for( int i=0 ; i<=precision ; i++ )
            {
                add_to_node.get_lp_coef_x().add(0.0);
                add_to_node.get_lp_coef_y().add(0.0);
            }
            add_to_node.set_lp_coef_calculated(true);
        }
        
        FM3_QuadTreeNode parent = add_to_node.get_parent();
        Point2D z0 = new Point2D(parent.get_Sm().getCenterX(), parent.get_Sm().getCenterY());
        Point2D z1 = new Point2D(add_to_node.get_Sm().getCenterX(), add_to_node.get_Sm().getCenterY());
        Point2D dist = new Point2D( (z1.getX()-z0.getX()), (z1.getY()-z0.getY()) );
        Point2D parent_coef;
        int bc;
        for( int l=0 ; l<=precision ; l++ )
        {
            double sumx=0.0, sumy=0.0;
            Point2D sum = new Point2D( 0.0, 0.0 );
            for( int k=l ; k<=precision ; k++ )
            {
                bc = binomial_coefficient(k,l);
                parent_coef = new Point2D( parent.get_lp_coef_x().get(k), parent.get_lp_coef_y().get(k) );
                sum = complex_add( sum, complex_multiply( parent_coef, complex_multiply( complex_pow(dist, (k-l)), (double)bc ) ) );
            }
            sumx = sum.getX();
            sumy = sum.getY();
            
            add_to_node.get_lp_coef_x().set(l, add_to_node.get_lp_coef_x().get(l)+sumx);
            add_to_node.get_lp_coef_y().set(l, add_to_node.get_lp_coef_y().get(l)+sumy);
        }
    }
    
    // Counter for elapsed time
    private class Counter
    {
        Counter(){};
        
        public void start(){ time_start = System.nanoTime(); }
        public void stop()
        {
            time_end = System.nanoTime();
            time_nanos = time_end - time_start;
            time_micros = time_nanos / 1000.0;
            time_millis = time_micros / 1000.0;
            time_seconds = time_millis / 1000.0;
        }
        public double get_elapsed_time_nano(){ return time_nanos; }
        public double get_elapsed_time_micro(){ return time_micros; }
        public double get_elapsed_time_milli(){ return time_millis; }
        public double get_elapsed_time(){ return time_seconds; }
        
        private long time_start;
        private long time_end;
        private double time_nanos;
        private double time_millis;
        private double time_micros;
        private double time_seconds;
    }
    
    // Counter for edge crossings
    private class Edge_Cross_Counter
    {
        Edge_Cross_Counter(){};
        
        public void calculate()
        {
            for( Iterator<FM3_Edge> iter =  fm3_graph.edges() ; iter.hasNext() ; )
            {
                FM3_Edge edge = iter.next();
                FM3_Node src1 = edge.get_source();
                FM3_Node trg1 = edge.get_target();
                x1_line1 = (int)src1.get_visual_node().getX();
                x2_line1 = (int)trg1.get_visual_node().getX();
                y1_line1 = (int)src1.get_visual_node().getY();
                y2_line1 = (int)trg1.get_visual_node().getY();
                A_line1 = y2_line1 - y1_line1;
                B_line1 = x1_line1 - x2_line1;
                C_line1 = A_line1 * x1_line1 + B_line1 * y1_line1;
                for( Iterator<FM3_Edge> iter2 =  fm3_graph.edges() ; iter2.hasNext() ; )
                {
                    FM3_Edge edge2 = iter2.next();
                    if( edge == edge2 )
                        continue;
                    FM3_Node src2 = edge2.get_source();
                    FM3_Node trg2 = edge2.get_target();
                    x1_line2 = (int)src2.get_visual_node().getX();
                    x2_line2 = (int)trg2.get_visual_node().getX();
                    y1_line2 = (int)src2.get_visual_node().getY();
                    y2_line2 = (int)trg2.get_visual_node().getY();
                    A_line2 = y2_line2 - y1_line2;
                    B_line2 = x1_line2 - x2_line2;
                    C_line2 = A_line2 * x1_line2 + B_line2 * y1_line2;
                    
                    det = A_line1*B_line2 - A_line2*B_line1;
                    if( det != 0 )
                    {
                        intersect_x = (B_line2*C_line1 - B_line1*C_line2)/det;
                        intersect_y = (A_line1*C_line2 - A_line2*C_line1)/det;
                        if( Math.min( x1_line1 , x2_line1 ) < intersect_x && Math.max( x1_line1 , x2_line1 ) > intersect_x
                                && Math.min( y1_line1 , y2_line1 ) < intersect_y && Math.max( y1_line1 , y2_line1 ) > intersect_y
                                && Math.min( x1_line2 , x2_line2 ) < intersect_x && Math.max( x1_line2 , x2_line2 ) > intersect_x
                                && Math.min( y1_line2 , y2_line2 ) < intersect_y && Math.max( y1_line2 , y2_line2 ) > intersect_y )
                            edge_cross_count++;
                    }
                }
            }
            edge_cross_count /= 2;
            System.out.println("Edge Crossings: "+edge_cross_count);
        }
        
        private double A_line1;
        private double A_line2;
        private double B_line1;
        private double B_line2;
        private double C_line1;
        private double C_line2;
        private double det;
        private double intersect_x;
        private double intersect_y;
        private double x1_line1;
        private double x2_line1;
        private double y1_line1;
        private double y2_line1;
        private double x1_line2;
        private double x2_line2;
        private double y1_line2;
        private double y2_line2;
        private int edge_cross_count=0;
    }
}