/*  
 * Copyright (c) 2004-2013 Regents of the University of California.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 3.  Neither the name of the University nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * Copyright (c) 2014 Martin Stockhammer
 */
package prefux.data.tuple;

import java.beans.PropertyChangeListener;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.event.SwingPropertyChangeSupport;

import prefux.data.Schema;
import prefux.data.Table;
import prefux.data.Tuple;
import prefux.data.event.EventConstants;
import prefux.data.event.TupleSetListener;
import prefux.data.expression.Expression;
import prefux.data.expression.Predicate;
import prefux.data.util.FilterIteratorFactory;
import prefux.data.util.Sort;
import prefux.data.util.SortedTupleIterator;
import prefux.util.collections.CopyOnWriteArrayList;

/**
 * Abstract base class for TupleSet implementations. Provides mechanisms for
 * generating filtered tuple iterators, maintain listeners, and supporting
 * bound client properties.
 * 
 * @author <a href="http://jheer.org">jeffrey heer</a>
 */
public abstract class AbstractTupleSet implements TupleSet {
    
    /**
     * @see prefux.data.tuple.TupleSet#tuples(prefux.data.expression.Predicate)
     */
    public Iterator<? extends Tuple> tuples(Predicate filter) {
        if ( filter == null ) {
            return tuples();
        } else {
            return FilterIteratorFactory.tuples(this, filter);
        }
    }
    
    /**
     * @see prefux.data.tuple.TupleSet#tuples(prefux.data.expression.Predicate, prefux.data.util.Sort)
     */
    public Iterator<? extends Tuple> tuples(Predicate filter, Sort sort) {
        if ( sort == null ) {
            return tuples(filter);
        } else {
            Comparator<? extends Tuple> c = sort.getComparator(this);
            return new SortedTupleIterator(tuples(filter),getTupleCount(),c);
        }
    }
    
    
    // -- TupleSet Methods ----------------------------------------------------
    
    private CopyOnWriteArrayList m_tupleListeners;
    
    /**
     * @see prefux.data.tuple.TupleSet#addTupleSetListener(prefux.data.event.TupleSetListener)
     */
    public void addTupleSetListener(TupleSetListener tsl) {
        if ( m_tupleListeners == null )
            m_tupleListeners = new CopyOnWriteArrayList();
        if ( !m_tupleListeners.contains(tsl) )
            m_tupleListeners.add(tsl);
    }
    
    /**
     * @see prefux.data.tuple.TupleSet#removeTupleSetListener(prefux.data.event.TupleSetListener)
     */
    public void removeTupleSetListener(TupleSetListener tsl) {
        if ( m_tupleListeners != null ) {
            m_tupleListeners.remove(tsl);
        }
    }
    
    /**
     * Fire a Tuple event.
     * @param t the Table on which the event has occurred
     * @param start the first row changed
     * @param end the last row changed
     * @param type the type of event, one of
     * {@link prefux.data.event.EventConstants#INSERT} or
     * {@link prefux.data.event.EventConstants#DELETE}.
     */
    protected void fireTupleEvent(Table t, int start, int end, int type) {
        if ( m_tupleListeners != null && m_tupleListeners.size() > 0 ) {
            Object[] lstnrs = m_tupleListeners.getArray();
            Tuple[] tuples = new Tuple[end-start+1];
            for ( int i=0, r=start; r <= end; ++r, ++i ) {
                tuples[i] = t.getTuple(r);
            }
            for ( int i=0; i<lstnrs.length; ++i ) {
                TupleSetListener tsl = (TupleSetListener)lstnrs[i];
                if ( type == EventConstants.INSERT ) {
                    tsl.tupleSetChanged(this, tuples, EMPTY_ARRAY);
                } else {
                    tsl.tupleSetChanged(this, EMPTY_ARRAY, tuples);
                }
            }
        }
    }
    
    /**
     * Fire a Tuple event.
     * @param t the tuple that has been added or removed
     * @param type the type of event, one of
     * {@link prefux.data.event.EventConstants#INSERT} or
     * {@link prefux.data.event.EventConstants#DELETE}.
     */
    protected void fireTupleEvent(Tuple t, int type) {
        if ( m_tupleListeners != null && m_tupleListeners.size() > 0 ) {
            Object[] lstnrs = m_tupleListeners.getArray();
            Tuple[] ts = new Tuple[] {t};
            for ( int i=0; i<lstnrs.length; ++i ) {
                TupleSetListener tsl = (TupleSetListener)lstnrs[i];
                if ( type == EventConstants.INSERT ) {
                    tsl.tupleSetChanged(this, ts, EMPTY_ARRAY);
                } else {
                    tsl.tupleSetChanged(this, EMPTY_ARRAY, ts);
                }
            }
        }
    }
    
    /**
     * Fire a Tuple event.
     * @param added array of Tuples that have been added, can be null
     * @param removed array of Tuples that have been removed, can be null
     */
    protected void fireTupleEvent(Tuple[] added, Tuple[] removed) {
        if ( m_tupleListeners != null && m_tupleListeners.size() > 0 ) {
            Object[] lstnrs = m_tupleListeners.getArray();
            added = added==null ? EMPTY_ARRAY : added;
            removed = removed==null ? EMPTY_ARRAY : removed;
            for ( int i=0; i<lstnrs.length; ++i ) {
                TupleSetListener tsl = (TupleSetListener)lstnrs[i];
                tsl.tupleSetChanged(this, added, removed);
            }
        }
    }
    
    // -- Data Field Methods --------------------------------------------------
    
    /**
     * False by default.
     * @see prefux.data.tuple.TupleSet#isAddColumnSupported()
     */
    public boolean isAddColumnSupported() {
        return false;
    }

    /**
     * @see prefux.data.tuple.TupleSet#addColumns(prefux.data.Schema)
     */
    public void addColumns(Schema schema) {
        if ( isAddColumnSupported() ) {
            for ( int i=0; i<schema.getColumnCount(); ++i ) {
                try {
                    addColumn(schema.getColumnName(i), 
                              schema.getColumnType(i),
                              schema.getDefault(i));
                } catch ( IllegalArgumentException iae ) {}
            }
        } else {
            throw new UnsupportedOperationException();
        }
    }
    
    /**
     * Unsupported by default.
     * @see prefux.data.tuple.TupleSet#addColumn(java.lang.String, java.lang.Class, java.lang.Object)
     */
    public void addColumn(String name, Class<?> type, Object defaultValue) {
        throw new UnsupportedOperationException();
    }

    /**
     * Unsupported by default.
     * @see prefux.data.tuple.TupleSet#addColumn(java.lang.String, java.lang.Class)
     */
    public void addColumn(String name, Class<?> type) {
        throw new UnsupportedOperationException();
    }

    /**
     * Unsupported by default.
     * @see prefux.data.tuple.TupleSet#addColumn(java.lang.String, prefux.data.expression.Expression)
     */
    public void addColumn(String name, Expression expr) {
        throw new UnsupportedOperationException();
    }

    /**
     * Unsupported by default.
     * @see prefux.data.tuple.TupleSet#addColumn(java.lang.String, java.lang.String)
     */
    public void addColumn(String name, String expr) {
        throw new UnsupportedOperationException();
    }
    
    public abstract boolean hasColumn(String name);
    
    // -- Client Properties ---------------------------------------------------
    
    private HashMap<String,Object> m_props;
    private SwingPropertyChangeSupport m_propSupport;
    
    /**
     * @see prefux.data.tuple.TupleSet#addPropertyChangeListener(java.beans.PropertyChangeListener)
     */
    public void addPropertyChangeListener(PropertyChangeListener lstnr) {
        if ( lstnr == null ) return;
        if ( m_propSupport == null )
            m_propSupport = new SwingPropertyChangeSupport(this);
        m_propSupport.addPropertyChangeListener(lstnr);
    }
    
    /**
     * @see prefux.data.tuple.TupleSet#addPropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
     */
    public void addPropertyChangeListener(String key, 
                                          PropertyChangeListener lstnr)
    {
        if ( lstnr == null ) return;
        if ( m_propSupport == null )
            m_propSupport = new SwingPropertyChangeSupport(this);
        m_propSupport.addPropertyChangeListener(key, lstnr);
    }
    
    /**
     * @see prefux.data.tuple.TupleSet#removePropertyChangeListener(java.beans.PropertyChangeListener)
     */
    public void removePropertyChangeListener(PropertyChangeListener lstnr) {
        if ( lstnr == null ) return;
        if ( m_propSupport == null ) return;
        m_propSupport.removePropertyChangeListener(lstnr);
    }
    
    /**
     * @see prefux.data.tuple.TupleSet#removePropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
     */
    public void removePropertyChangeListener(String key,
                                             PropertyChangeListener lstnr)
    {
        if ( lstnr == null ) return;
        if ( m_propSupport == null ) return;
        m_propSupport.removePropertyChangeListener(key, lstnr);
    }
    
    /**
     * @see prefux.data.tuple.TupleSet#putClientProperty(java.lang.String, java.lang.Object)
     */
    public void putClientProperty(String key, Object value) {
        Object prev = null;
        if ( m_props == null && value == null ) {
            // nothing to do
            return;
        } else if ( value == null ) {
            prev = m_props.remove(key);
        } else {
            if ( m_props == null )
                m_props = new HashMap<String, Object>(2);
            prev = m_props.put(key, value);
        }
        if ( m_propSupport != null )
            m_propSupport.firePropertyChange(key, prev, value);
    }
    
    /**
     * @see prefux.data.tuple.TupleSet#getClientProperty(java.lang.String)
     */
    public Object getClientProperty(String key) {
        return ( m_props == null ? null : m_props.get(key) );
    }
    
} // end of class AbstractTupleSet
