/*  
 * Author: Daniel Sund
 * Read .owl file into a Graph
 */
package prefux.data.io;

import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;
import java.util.Iterator;

// prefux
import prefux.data.Graph;
import prefux.data.Node;
import prefux.data.Edge;

// Jena
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.ObjectProperty;
import com.hp.hpl.jena.ontology.OntResource;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;


/*
    This class should read an .owl file into a Jena OntModel
    and then convert that OntModel into a Prefux Graph.
*/
public class GraphOWLReader
{
    // Jena OntModel to be converted
    private final OntModel jena_ontology_model = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM, null);
    
    // Prefux Graph to be returned
    private Graph prefux_graph = null;
    
    // Array of the prefux graph's nodes
    private final Map<String,Node> graph_nodes = new HashMap<>();
    
    // Array of the prefux graph's edges
    private final ArrayList<String[]> graph_edges = new ArrayList<>();
    
    public Graph get_graph(){ return prefux_graph; }
    
    public OntModel get_model(){ return jena_ontology_model; }
    
    // Read OWL-files and create a prefux graph
    public Graph readOWL( String owl_path, boolean directed ) throws DataIOException
    {
        try
        {
            // 1. Read .owl file to the OntModel
            jena_ontology_model.read("file:///"+owl_path);
            
            // 2. Create the Graph from the OntModel
            create_graph(directed);
            
            return prefux_graph;
        }
        catch ( Exception e )
        {
            if ( e instanceof DataIOException )
                throw (DataIOException)e;
            else
                throw new DataIOException(e);
        }
    }
    
    // Create the graph
    private void create_graph( boolean directed )
    {
        // Initialize the graph
        initialize_graph( directed );
        
        // Create the class nodes
        Iterator<OntClass> cls_it = jena_ontology_model.listNamedClasses();
        while( cls_it.hasNext() )
        {
            OntClass cls = cls_it.next();
            
            // Create this node
            Node class_node = prefux_graph.addNode();
            class_node.setString( "id", cls.getURI() );
            class_node.setString( "name", cls.getLocalName() );
            class_node.setString( "type", "Class" );
            graph_nodes.put( cls.getURI(), class_node );
            
            // Get data from this class, for creating edges later
            get_edge_data( cls );
        }
        
        // Create the ObjectProperty edges
        Iterator<ObjectProperty> o_prop_it = jena_ontology_model.listObjectProperties();
        while( o_prop_it.hasNext() )
        {
            ObjectProperty o_prop = o_prop_it.next();
            
            if( o_prop.getURI() != null && o_prop.getDomain() != null && o_prop.getRange() != null
                    && o_prop.getDomain().getURI() != null && o_prop.getRange().getURI() != null)
            {
                String source_id = o_prop.getDomain().getURI();
                String name = o_prop.getLocalName();
                String target_id = o_prop.getRange().getURI();

                // Edge
                String[] edge_data = new String[3];
                edge_data[0] = source_id;
                edge_data[1] = target_id;
                edge_data[2] = name;
                graph_edges.add(edge_data);
            }
        }
        
        create_edges();
    }
    
    // Get data necessary for the creation of edges
    private void get_edge_data( OntResource res )
    {
        if( res.canAs( OntClass.class ) ) // Handle OntClass
        {
            // One edge for every sub-class relation
            String source_id = res.getURI();
            String name;
            StmtIterator stmt_it = res.listProperties();
            while( stmt_it.hasNext() )
            {
                Statement property = stmt_it.next();
                name = property.getPredicate().getLocalName();
                
                if( name.equals("subClassOf") && property.getResource().getURI() != null )
                {
                    String target_id = property.getResource().getURI();
                    String[] edge_data = new String[3];
                    edge_data[0] = source_id;
                    edge_data[1] = target_id;
                    edge_data[2] = name;
                    graph_edges.add(edge_data);
                }
            }
        }
    }
    
    // Create the edges of the graph
    private void create_edges()
    {
        for( String[] edge_data : graph_edges )
        {
            Node src = graph_nodes.get(edge_data[0]);
            Node trg = graph_nodes.get(edge_data[1]);
            
            if( src != null && trg != null )
            {
                Edge edge = prefux_graph.addEdge(src, trg);
                edge.setString("name", edge_data[2]);
                edge.setString("type", "Property");
            }
        }
    }
    
    // Initialize the graph
    private void initialize_graph( boolean directed )
    {
        prefux_graph = new Graph( directed );
        prefux_graph.addColumn( "id", String.class ); // URI for nodes and edges
        prefux_graph.addColumn( "src_id", String.class ); // Source URI for edges (null for node entries)
        prefux_graph.addColumn( "trg_id", String.class ); // Target URI for edges (null for node entries)
        prefux_graph.addColumn( "name", String.class ); // Local Name of Class or Property
        prefux_graph.addColumn( "type", String.class ); // Type: "Class" or "Property"
    }
}