/*  
 * Copyright (c) 2004-2013 Regents of the University of California.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 3.  Neither the name of the University nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * Copyright (c) 2014 Martin Stockhammer
 */
package prefux.controls;

import javafx.event.Event;
import javafx.event.EventType;
import javafx.scene.Cursor;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;

// Touch-functionality
import javafx.scene.input.TouchEvent;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import prefux.data.Table;
import prefux.data.event.EventConstants;
import prefux.data.event.TableListener;
import prefux.data.util.Point2D;
import prefux.util.PrefuseLib;
import prefux.visual.VisualItem;

/**
 * Changes a node's location when dragged on screen. Other effects include
 * fixing a node's position when the mouse if over it, and changing the mouse
 * cursor to a hand when the mouse passes over an item.
 *
 * @author <a href="http://jheer.org">jeffrey heer</a>
 */
public class DragControl extends ControlAdapter implements TableListener {

	private VisualItem	        activeItem;
	protected String	        action;
	protected Point2D	        down	       = new Point2D();
	protected Point2D	        temp	       = new Point2D();
	protected boolean	        dragged, wasFixed, resetItem;
	private boolean	            fixOnMouseOver	= true;
	
	private static final Logger log = LogManager.getLogger(DragControl.class);
	private final Delta	            delta	       = new Delta();

	/**
	 * Creates a new drag control that issues repaint requests as an item is
	 * dragged.
	 */
	public DragControl() {
	}

	/**
	 * Creates a new drag control that invokes an action upon drag events.
	 * 
	 * @param action
	 *            the action to run when drag events occur.
	 */
	public DragControl(String action) {
		this.action = action;
	}

	/**
	 * Creates a new drag control that invokes an action upon drag events.
	 * 
	 * @param action
	 *            the action to run when drag events occur
	 * @param fixOnMouseOver
	 *            indicates if object positions should become fixed (made
	 *            stationary) when the mouse pointer is over an item.
	 */
	public DragControl(String action, boolean fixOnMouseOver) {
		this.fixOnMouseOver = fixOnMouseOver;
		this.action = action;
	}

	/**
	 * Determines whether or not an item should have it's position fixed when
	 * the mouse moves over it.
	 * 
	 * @param s
	 *            whether or not item position should become fixed upon mouse
	 *            over.
	 */
	public void setFixPositionOnMouseOver(boolean s) {
		fixOnMouseOver = s;
	}

	@Override
	public void itemEvent(VisualItem item, Event e)
        {
		activeItem = item;
		if (e.getEventType() == MouseEvent.MOUSE_PRESSED)
                {
                    MouseEvent ev = (MouseEvent) e;
                    if( ev.getButton() == MouseButton.PRIMARY )
                    {
                        delta.x = item.getX() - ev.getSceneX();
                        delta.y = item.getY() - ev.getSceneY();
                        item.getNode().setCursor(Cursor.MOVE);
                    }
		}
                else if (e.getEventType() == MouseEvent.DRAG_DETECTED)
                {
                    MouseEvent ev = (MouseEvent) e;
                    if( ev.getButton() == MouseButton.PRIMARY )
                    {
                        log.info("Drag Event detected");
                        wasFixed = item.isFixed();
                        resetItem = true;
                        activeItem = item;
                        item.setFixed(true);
                        item.getTable().addTableListener(this);
                        PrefuseLib.setX(activeItem, null, ev.getSceneX() + delta.x);
                        PrefuseLib.setY(activeItem, null, ev.getSceneY() + delta.y);
                    }
		}
                else if (e.getEventType() == MouseEvent.MOUSE_DRAGGED)
                {
                    MouseEvent ev = (MouseEvent) e;
                    if (activeItem != null && ev.getButton() == MouseButton.PRIMARY)
                    {
                        item.setFixed(true); // fixing the item to the cursors position
                        PrefuseLib.setX(activeItem, null, ev.getSceneX() + delta.x);
                        PrefuseLib.setY(activeItem, null, ev.getSceneY() + delta.y);
                    }
		}
                else if (e.getEventType() == MouseDragEvent.MOUSE_DRAG_RELEASED ||
				e.getEventType() == MouseEvent.MOUSE_RELEASED)
                {
                    MouseEvent ev = (MouseEvent) e;
                    if (activeItem != null && ev.getButton()==MouseButton.PRIMARY)
                    {
                        activeItem.setFixed(false);
                        activeItem = null;
                    }
		}
                // Touch-functionality
                else if( e.getEventType() == TouchEvent.TOUCH_PRESSED )
                {
                    // Interpret just like a press with a mouse
                    TouchEvent ev = (TouchEvent) e;
                    if ( ev.getTouchCount()!=1 ) return; // Exit if more than 1 touchpoint are used
                    delta.x = item.getX() - ev.getTouchPoint().getSceneX();
                    delta.y = item.getY() - ev.getTouchPoint().getSceneY();
                    item.getNode().setCursor(Cursor.MOVE);
                }
                else if( e.getEventType() == TouchEvent.TOUCH_RELEASED )
                {
                    // Interpret just like a release with a mouse
                    if (activeItem != null)
                    {
                        activeItem.setFixed(false);
                        activeItem = null;
                    }
                }
                else if( e.getEventType() == TouchEvent.TOUCH_MOVED )
                {
                    // Interpret just like a drag event with a mouse. Combine detection and dragged above?
                    TouchEvent ev = (TouchEvent) e;
                    if ( ev.getTouchCount()!=1 ) return; // Exit if more than 1 touchpoint are used
                    if (activeItem != null) // DRAGGED
                    {
                        item.setFixed(true); // fixing the item to the cursors position
                        PrefuseLib.setX(activeItem, null, ev.getTouchPoint().getSceneX() + delta.x);
                        PrefuseLib.setY(activeItem, null, ev.getTouchPoint().getSceneY() + delta.y);
                    }
                }
        }

	@Override
	public EventType<? extends Event> getEventType() {
		return MouseEvent.ANY;
	}

	/**
	 * @see prefux.data.event.TableListener#tableChanged(prefux.data.Table, int,
	 *      int, int, int)
	 */
	public void tableChanged(Table t, int start, int end, int col, int type) {
		if (activeItem == null || type != EventConstants.UPDATE
		        || col != t.getColumnNumber(VisualItem.FIXED))
			return;
		int row = activeItem.getRow();
		if (row >= start && row <= end)
			resetItem = false;
	}
        

} // end of class DragControl
