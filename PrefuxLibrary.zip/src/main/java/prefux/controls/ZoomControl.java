package prefux.controls;

import javafx.event.Event;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ZoomEvent;
import prefux.FxDisplay;
import prefux.data.util.Point2D;
import prefux.visual.VisualItem;


/**
 * Zooms the display, changing the scale of the viewable region. By default,
 * zooming is achieved by pressing the right mouse button on the background
 * of the visualization and dragging the mouse up or down. Moving the mouse up
 * zooms out the display around the spot the mouse was originally pressed.
 * Moving the mouse down similarly zooms in the display, making items
 * larger.
 *
 * @author <a href="http://jheer.org">jeffrey heer</a>
 */
public class ZoomControl extends ControlAdapter {
    
    private double yLast;
    private double zoomValue = 1;
    private Point2D anchor;
    //private Point2D down = new Point2D.Float();
    //private int button = RIGHT_MOUSE_BUTTON;
    private FxDisplay display;
    
    /**
     * Create a new zoom control.
     */
    public ZoomControl() {
        // do nothing
    }
    
    /**
     * Create a new zoom control.
     * @param _display the display to zoom
     */
    public ZoomControl(FxDisplay _display) {
        display = _display;
    }
    
    /**
     * Create a new zoom control.
     * @param mouseButton the mouse button that should initiate a zoom. One of
     * {@link Control#LEFT_MOUSE_BUTTON}, {@link Control#MIDDLE_MOUSE_BUTTON},
     * or {@link Control#RIGHT_MOUSE_BUTTON}.
     *//*
    public ZoomControl(int mouseButton) {
        button = mouseButton;
    }*/
    
    @Override
    public void itemEvent(VisualItem item, Event e)
    {
        //event(e);
    }
    
    @Override
    public void event(Event e)
    {
        if( e.getEventType() == MouseEvent.MOUSE_PRESSED )
        {
            MouseEvent ev = (MouseEvent)e;
            if ( ev.isSecondaryButtonDown() )
            {
                yLast = ev.getY();
                anchor = new Point2D(ev.getX(),ev.getY());
            }
        }
        else if( e.getEventType() == MouseEvent.MOUSE_DRAGGED )
        {
            MouseEvent ev = (MouseEvent)e;
            if ( ev.isSecondaryButtonDown() )
            {
                // Drag up   = Zoom out
                // Drag down = Zoom in
                double y = ev.getY();
                double dy = y-yLast;
                zoomValue += dy/100;
                if( zoomValue > 2 )
                    zoomValue = 2;
                else if( zoomValue < 0.05 )
                    zoomValue = 0.05;
                display.zoom( anchor, zoomValue);
                yLast = y;
            }
        }
        else if( e.getEventType() == ZoomEvent.ZOOM_STARTED)
        {
            ZoomEvent ev = (ZoomEvent)e;
            anchor = new Point2D(ev.getX(),ev.getY());
        }
        else if( e.getEventType() == ZoomEvent.ZOOM)
        {
            ZoomEvent ev = (ZoomEvent)e;
            zoomValue = ev.getTotalZoomFactor();
            display.zoom(anchor, zoomValue);
        }
    }
    
} // end of class ZoomControl
