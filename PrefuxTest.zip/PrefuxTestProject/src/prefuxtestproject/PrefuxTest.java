/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prefuxtestproject;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.Event;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import prefux.Constants;
import prefux.FxDisplay;
import prefux.Visualization;
import prefux.action.ActionList;
import prefux.action.RepaintAction;
import prefux.action.assignment.DataColorAction;
import prefux.action.assignment.SizeAction;
import prefux.action.layout.graph.FM3Layout;
import prefux.action.layout.graph.ForceDirectedLayout;
import prefux.controls.DragControl;
import prefux.controls.FocusControl;
import prefux.controls.ZoomControl;
import prefux.data.Graph;
import prefux.data.io.DataIOException;
import prefux.data.io.GraphMLReader;
import prefux.data.io.GraphOWLReader;
import prefux.util.ColorLib;
import prefux.util.PrefuseLib;
import prefux.visual.VisualItem;
import prefux.visual.expression.InGroupPredicate;

/**
 *
 * @author Daniel
 */
public class PrefuxTest extends Application
{
    public static void main(String[] args)
    {
        launch(args);
    }
    
    private static final double WIDTH = 800; //300;
    private static final double HEIGHT = 600; //250;
    private static final String GROUP = "graph";
    
    @Override
    public void start(Stage primaryStage)
    {
        // The Primary stage (program)
        primaryStage.setTitle("Prefux Test");
        
        // Window borders (create a new window)
        BorderPane root = new BorderPane();
        
        // Set primary stage (program) to have a new scene in the window
        primaryStage.setScene(new Scene(root, WIDTH, HEIGHT));
        
        // the window is made part of a class called "display"
        root.getStyleClass().add("display");
        
        // Show the window on the user interface
        primaryStage.show();
        
        // A graph object set to null
        Graph graph = null;
        try
        {
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/crs_dr.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/PCS.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/cmt.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/MICRO.owl", true);
            graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/linklings.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/confOf.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/MyReview.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/paperdyne.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/sigkdd.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/Cocus.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/confious.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/Conference.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/OpenConf.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/ekaw.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/edas.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Conference/iasted.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Anatomy/mouse.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Anatomy/human.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Large Biomedical/oaei2014_FMA_small_overlapping_nci.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Large Biomedical/oaei2014_NCI_small_overlapping_fma.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Large Biomedical/oaei2014_FMA_small_overlapping_snomed.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Large Biomedical/oaei2014_SNOMED_small_overlapping_fma.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Large Biomedical/oaei2014_NCI_small_overlapping_snomed.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Large Biomedical/oaei2014_SNOMED_small_overlapping_nci.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Large Biomedical/oaei2014_NCI_whole_ontology.owl", true);
            //graph = new GraphOWLReader().readOWL("C:/Users/Daniel/Documents/LIU Kurser/Exjobb/Implementation/Parsing OWL Files/Datasets From OAEI/Large Biomedical/oaei2014_FMA_whole_ontology.owl", true);
            
            System.out.println("Size: N "+graph.getNodeCount()+", E "+graph.getEdgeCount());
            
            // Create a new visualization object
            Visualization vis = new Visualization();
            
            // Adding a group-name and a graph to the visualization object
            vis.add(GROUP, graph);
            
            // Create an actionlist called layout
            ActionList layout = new ActionList(1,30);
            
            // Add the forcedirected layout to it and place it on the visualization
            //layout.add(new ForceDirectedLayout("graph", false, true));
            layout.add(new FM3Layout("graph", 50.0, 0.01, 100.0, 0.5, 0.2));
            layout.add(new RepaintAction());
            vis.putAction("layout", layout);
            
            final String NODES = PrefuseLib.getGroupName(GROUP, Graph.NODES); // "NODES" = String for the group containing all nodes
            
            FxDisplay display = new FxDisplay(vis);
            
            // Control Listeners
            display.addControlListener(new DragControl());
            display.addControlListener(new ZoomControl(display));
            
            // Handler for empty space events
            root.addEventHandler(Event.ANY, display);
            
            // Node Features
            ActionList nodeActions = new ActionList(); // List of actions performed on nodes
            SizeAction size = new SizeAction(NODES, 2.0); // Set size for nodes
            int[] class_color = new int[] {ColorLib.rgb(240,200,20)}; // Palette with gold color
            DataColorAction node_color = new DataColorAction( NODES, "id", Constants.NOMINAL, VisualItem.FILLCOLOR, class_color );
            nodeActions.add(node_color);
            nodeActions.add(size);
            
            // ----------FocusControl----------
            int[] testPalette = new int[] {ColorLib.rgb(255,0,0)}; // Palette with red color
            InGroupPredicate inFocusGroup = new InGroupPredicate( Visualization.FOCUS_ITEMS ); // Predicate, only applies action to nodes in FocusGroup
            // New data-color action (Nodes in focus will be colored red)
            DataColorAction FocusColor = new DataColorAction(NODES, inFocusGroup, "id", Constants.NOMINAL, VisualItem.FILLCOLOR, testPalette);
            nodeActions.add(FocusColor); // Add the color-change action to the list of actions.
            vis.putAction("nodes", nodeActions);
            display.addControlListener(new FocusControl(1,"nodes")); // add a control listener for FocusControl
            //----------End of FocusControl----------
            
            root.setCenter(display);
            
            vis.run("nodes");
            vis.run("layout");
        }
        catch (DataIOException e)
        {
            e.printStackTrace();
            System.err.println("Error loading graph. Exiting...");
            System.exit(1);
        }
    }
}
